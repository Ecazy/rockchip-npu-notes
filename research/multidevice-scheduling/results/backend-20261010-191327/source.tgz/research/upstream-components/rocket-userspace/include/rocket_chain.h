// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 The rocket-userspace authors
/*
 * rocket_chain.h — contiguous self-chaining regcmd layout for batched NPU submit.
 *
 * A multi-task NPU job can run as ONE hardware kick over CONTIGUOUS regcmds when
 * each task's trailer redirects the PC to the next task (an embedded
 * PC_BASE_ADDRESS write, plus the next segment's PC_REGISTER_AMOUNTS length) and
 * the kernel sets PC_TASK_CON.TASK_NUMBER = N to gate a single completion IRQ.
 * The PC_BASE_ADDRESS redirect is LOAD-BEARING: with the address left pointing at
 * task 0 the PC runs task 0 and stops, regardless of the amount.
 *
 * This is the SINGLE point where the gapped-vs-contiguous regcmd layout is
 * decided, shared by every submit path (matmul fp16/int8/int4, conv, ...). Each
 * path keeps its own gapped slot stride (the matmul/int8/int4 paths use 128 u64
 * words); the chained stride is always the regcmd word count rounded up to a
 * 128-bit (2-u64) boundary. The chain rewrites only the inert OP_NONE filler in
 * the trailer [OP_NONE, PC_REGISTER_AMOUNTS, OP_40, OP_ENABLE] that every gen_*
 * emits, so the op count — and so the stride — is unchanged.
 *
 * NOT a public/installed header.
 */
#ifndef ROCKET_CHAIN_H
#define ROCKET_CHAIN_H

#include <stddef.h>
#include <stdint.h>
#include "rocket_npu.h"   /* rocket_bo, rocket_task_desc */

/* Whether contiguous chaining is requested (ROCKET_BATCH_SUBMIT=1). Read once.
 * A chained batch must be uniform-length (the gen op count is data-independent
 * per dtype); a caller mixing regcmd lengths in one job must keep it off and let
 * each task keep its own gapped slot. The userspace half pairs with the kernel
 * `rocket_batch_submit=1` param — enable BOTH together or a chained stream runs
 * task 0 into the gap and times out. */
int rkt_chain_enabled(void);

/* The chained per-task stride in u64 words = the PC's per-task advance: the
 * regcmd word count rounded up to a 128-bit (2-u64) boundary. For the matmul's
 * even op counts this equals the count exactly (no padding). */
size_t rkt_chain_words(uint32_t regcmd_count);

/* Pack tile `nb`'s freshly generated regcmd (`src`, `count` u64 ops) into the
 * regcmd BO `rcbo` and fill its task descriptor `tasks[nb]`. When `chained`, lay
 * it contiguously at rkt_chain_words(count) stride and link its trailer to the
 * next task (next address + next stream length); otherwise use the caller's
 * `gapped_stride`-word slot. Mixed-length batches must pass chained=0.
 *
 * Returns 0, or -1 if the slot does not fit the BO, its address does not fit the
 * regcmd's 32-bit address field, or the trailer shape is not the one the chain
 * claims — in which case the caller must NOT submit the batch. Same contract as
 * rkt_chain_pack_at: a failure here means the chain link was not written and the
 * job would run task 0 and stall into a fence timeout. */
int rkt_chain_pack(int chained, rocket_bo *rcbo, rocket_task_desc *tasks,
                   int nb, const uint64_t *src, uint32_t count,
                   size_t gapped_stride);

/* THE SAME LINK, AT AN EXPLICIT OFFSET, for a chain whose programs are NOT all the same
 * length. rkt_chain_pack above derives task nb's slot from nb and this task's own count,
 * which is only a position when every program is the same size — true for a tile's row
 * tasks (they write the same registers with different values) and false across LAYERS,
 * where a depthwise program and a direct one differ.
 *
 * BOTH TRAILER FIELDS DESCRIBE THE NEXT SEGMENT, and a uniform-length chain cannot tell.
 * The kernel programs PC_BASE_ADDRESS and PC_REGISTER_AMOUNTS from task 0 alone, so for
 * every program after it the PREVIOUS program's trailer supplies the address to fetch from
 * AND how much to fetch — which is why `next_count` is a parameter and not `count`. Get it
 * wrong and the chain fetches a short segment as a long one: the affected program executes
 * partially or not at all, with nothing to fault on.
 *
 * `word_off` is where this program goes in the BO and `next_word_off` where the PC should
 * continue; pass next_word_off == word_off to mark the LAST program, whose forward link is
 * cleared instead (the hardware stops there on TASK_NUMBER, but a live address would have
 * the PC prefetch past the chain) and whose next_count is ignored. Fills tasks[idx].
 * Returns 0, or -1 if the trailer shape is not the one the chain claims — in which case the
 * caller must NOT submit the batch. */
int rkt_chain_pack_at(rocket_bo *rcbo, rocket_task_desc *tasks, int idx,
                      size_t word_off, size_t next_word_off,
                      const uint64_t *src, uint32_t count, uint32_t next_count);

/* Close a chained batch of `nb` tasks: the last task has no successor, so point
 * its embedded PC_BASE_ADDRESS link at 0 (TASK_NUMBER halts the PC after the last
 * OP_ENABLE, so this link is never followed — but a live address there would have
 * the PC prefetch past the batch). No-op when not chained or for a single task.
 * `count` is the uniform per-task op count (== tasks[0].regcmd_count). */
void rkt_chain_seal(int chained, rocket_bo *rcbo, int nb, uint32_t count);

/* Read back what was actually packed and check the chain is self-consistent: for
 * every task, that its trailer's PC_BASE_ADDRESS points at the NEXT task's regcmd
 * address and its PC_REGISTER_AMOUNTS encodes the NEXT task's word count, and that
 * the last task's forward link is cleared.
 *
 * This exists because rkt_chain_pack_at takes `next_count` as a parameter and
 * cannot check it: the caller asserts how long the next program is, and the header
 * says getting it wrong makes the chain fetch a short segment as a long one, with
 * nothing to fault on. Here the answer is available — the next program is really in
 * the BO — so the assertion becomes checkable. The uniform-length rkt_chain_pack
 * path derives both fields from one count and cannot get them inconsistent, so for
 * it this is a cheap tautology; the heterogeneous path is what it is for.
 *
 * CHAINED batches only: a gapped batch has no forward links to check, and every
 * task would read as one whose link was never written. `tasks[0..n)` must be the
 * descriptors the pack calls filled, in chain order. Returns 0, or -1 with a
 * diagnostic naming the first task whose link disagrees — the caller must not
 * submit. Reads the regcmd BO, so call it after packing (and after
 * rkt_chain_seal) and before submit. */
int rkt_chain_verify(const rocket_bo *rcbo, const rocket_task_desc *tasks, int n);

#endif /* ROCKET_CHAIN_H */
