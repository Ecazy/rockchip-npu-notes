// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 The rocket-userspace authors
/*
 * rk3576_perchannel_gate.c — rocket_conv2d_int8_perchannel_rk3576(), two ways.
 *
 * Per-axis weight scales are the form every real TFLite int8 and ONNX QDQ model
 * carries, and this part expresses them through the coefficient group's int16 C
 * multiplier against ONE OUT_CVT shift. That is close to a per-axis requant and not
 * equal to it, so the gate has two halves and they answer different questions.
 *
 *   BIT-EXACT — against a CPU model of what the CHIP computes:
 *       out = sat8( rhe( sat32(rhe(((acc + A[oc]) * C[oc]) >> BS)) * MUL >> SHIFT ) + out_zp )
 *   with the same (MUL, SHIFT), the same BS shift and the same C ramp the library planned
 *   (perchannel_model.h, a second spelling of the planner). A channel the planner programs
 *   as a CONSTANT is held to the exact per-axis byte instead, and its distance from an
 *   exact per-axis requant is asserted, not reported. A failure here is a defect in the
 *   emitter, the packing or the planner. This is the gate. `ROCKET_RK3576_PC_SHIFT=0` runs
 *   it against the shift-0 ramp (BS = 0, no constants), each cell's refusal following the
 *   ramp in force.
 *
 *   ACCURACY — against an exact per-axis float reference, the thing a model actually
 *   wants. This is REPORTED, not asserted: how far the two sit apart is a property of
 *   the datapath (one shift for every channel, an integer C, and an int32 product that
 *   saturates), not of the implementation, and the number is what a caller needs to
 *   decide whether the layer belongs on the NPU at all.
 *
 * The scale SPREAD is the axis that matters, because it is what forces the C ramp
 * wide, so the table sweeps it explicitly rather than taking whatever a random weight
 * draw produces.
 *
 * DEPTHWISE shapes are in the table too, and they are the interesting half: a real
 * per-axis model is mostly depthwise, and this path is both cheaper and closer there.
 * A depthwise task's accumulator is bounded by kh*kw taps rather than ic*kh*kw, so the
 * C ramp reaches the int16 field's own ceiling and one OUT_CVT shift covers the whole
 * layer -- one task, no output-channel split, and a spread of 1000x still lands inside
 * a count of an exact per-axis requant.
 *
 * Usage:  rk3576_perchannel_gate [name-substring]
 * Exit:   0 every shape bit-exact, 1 a shape failed, 2 no NPU (skip).
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <math.h>
#include <time.h>

#include "rocket_npu.h"
#include "rocket_conv.h"
#include "npu_matmul.h"
#include "npu_regcmd_rk3576.h"
#include "rocket_hw_profile.h"
#include "requant_model.h"
#include "perchannel_model.h"   /* plan_c: the ramp planner, a second implementation */

typedef struct {
    const char *name;
    unsigned ic, oc, iw, ih, k, stride, pad;
    float    spread;      /* w_scale[oc] spans [base, base*spread] */
    int      dw;          /* depthwise: oc == ic, one filter per channel */
    /* PRUNED CHANNELS — the last `dead` of them get an all-zero filter, the quantizer's
     * floor scale and `dead_bias`. This is the shape that actually clamps in a real
     * per-axis model: an all-zero filter is quantized against an all-zero tensor, so its
     * scale sits at the floor while its bias keeps the layer's magnitude, and its C falls
     * below the int16 field's floor of 1. Its accumulator is the fold ALONE at every
     * output position, so what the clamp does to it is exactly decidable — which is why
     * these cells come in a pair that differs only in `dead_bias`. */
    unsigned dead;
    int32_t  dead_bias;
    int      expect_refuse;   /* the SHIFT-0 ramp refuses: its clamp reaches the surface */
    int      refuse_bs;       /* the SHIFT ramp refuses: a LIVE channel below C's floor */
    /* The pruned channels' filters: 0 is all zero, k > 0 draws them from [-k, k] with at
     * least one non-zero tap, a LIVE channel whose output still cannot vary. */
    int      dead_w;
    /* Zero points, when set: the defaults are -7 and 11. An output zero point at the -128
     * rail hides the negative half of the product, so the new cells sit off it. */
    int      zp_set, in_zp, out_zp;
} pc_shape;

static const pc_shape SHAPES[] = {
    /* name          ic   oc   iw  ih   k  s  pad  spread   dw */
    { "flat",        32,  32,  16, 16,  1, 1, 0,   1.0f,    0 },
    { "narrow",      32,  32,  16, 16,  3, 1, 1,   2.0f,    0 },
    { "decade",      32,  64,  16, 16,  3, 1, 1,   10.0f,   0 },
    { "wide",        32,  64,  16, 16,  3, 1, 1,   100.0f,  0 },
    { "k1-64",       64,  64,   8,  8,  1, 1, 0,   10.0f,   0 },
    { "s2",          64,  32,  16, 16,  3, 2, 1,   10.0f,   0 },
    { "deep",       128,  64,   8,  8,  3, 1, 1,   10.0f,   0 },
    { "deep-wide",  128, 128,   8,  8,  3, 1, 1,   100.0f,  0 },
    { "big-plane",   32,  32,  28, 28,  3, 1, 1,   10.0f,   0 },
    { "k5",          32,  32,  16, 16,  5, 1, 2,   10.0f,   0 },
    { "oc-tile",     64, 256,   8,  8,  3, 1, 1,   10.0f,   0 },
    { "huge-fanin", 256, 128,   8,  8,  3, 1, 1,   10.0f,   0 },
    /* DEPTHWISE. The 48-byte coefficient group carries the same per-channel C, and a
     * depthwise task's accumulator is bounded by kh*kw taps rather than ic*kh*kw — so
     * the C ramp reaches the int16 field's own ceiling and a single OUT_CVT shift is
     * enough for the whole layer. A depthwise conv is one task by construction here:
     * output channel c is bound to input channel c, so there is no output-channel
     * window to program and no scale sort to make. A MobileNet is mostly depthwise,
     * which is what a per-axis model needs from this path. */
    { "dw-flat",     32,  32,  16, 16,  3, 1, 1,   1.0f,    1 },
    { "dw-decade",   32,  32,  16, 16,  3, 1, 1,   10.0f,   1 },
    { "dw-wide",     64,  64,  16, 16,  3, 1, 1,   100.0f,  1 },
    { "dw-k1",       32,  32,  16, 16,  1, 1, 0,   10.0f,   1 },
    { "dw-s2",       64,  64,  16, 16,  3, 2, 1,   10.0f,   1 },
    { "dw-k5",       32,  32,  16, 16,  5, 1, 2,   10.0f,   1 },
    { "dw-deep",    256, 256,   8,  8,  3, 1, 1,   100.0f,  1 },
    { "dw-1000x",    64,  64,  14, 14,  3, 1, 1,   1000.0f, 1 },
    /* PRUNED CHANNELS, as a PAIR. Both carry four all-zero filters at the quantizer's
     * floor scale, so both have channels whose C clamps to the field's floor of 1 and
     * whose gain is then the tile's base rather than their own. What differs is only the
     * fold those channels carry:
     *
     *   -5e8 drives it past the LOW saturation rail under either gain (-284 counts
     *   exactly, -877 clamped, against a rail at -139), so the surface is identical and
     *   the layer is ACCEPTED — the assertion is that the part's bytes on those channels
     *   equal an EXACT per-axis requant's, not merely the chip model's;
     *
     *   +1e8 lands inside the range (68 exactly, 127 saturated clamped), so the clamp
     *   reaches the surface and the entry must REFUSE.
     *
     * Nothing else about the two cells differs. A model that only sweeps the scale spread
     * cannot produce either: its channels all carry live filters. */
    { "pruned",      32,  64,  16, 16,  3, 1, 1,   100.0f,  0, 4, -500000000, 0 },
    { "dw-pruned",   64,  64,  16, 16,  3, 1, 1,   100.0f,  1, 4, -500000000, 0 },
    { "pruned-live", 32,  64,  16, 16,  3, 1, 1,   100.0f,  0, 4,  100000000, 1 },
    /* NARROW input channel counts, on the DIRECT datapath — the shape a per-axis model's
     * STEM is, and one no cell here reached while every such layer was refused for its
     * gain ramp. Four or fewer channels is where the library's other routing lives (the
     * packed-image first conv, which refuses a per-axis quantization outright), so the
     * ordinary encoding is the only one a per-axis stem can take and it is driven here.
     * `pc-stem` is EfficientDet-Lite0's own geometry. */
    { "pc-narrow3",   3,  32,  16, 16,  3, 1, 1,   100.0f,  0 },
    { "pc-narrow4",   4,  64,  16, 16,  3, 1, 1,   100.0f,  0 },
    { "pc-narrow1",   1,  32,  16, 16,  3, 1, 1,    10.0f,  0 },
    { "pc-stem",      3,  32, 320,320,  3, 2, 1,   100.0f,  0 },
    /* THE SHIFT RAMP'S OWN CELLS. Each is one the shift-0 ramp REFUSES and the shift ramp
     * computes, except the last, which both refuse — the boundary is a live channel below
     * 1/65534 of its task's largest scale, and the cell is what says the new ramp still
     * refuses at it. `pruned-live` above is the direct form of the first. Every zero point
     * is off the rail.
     *
     *   dw-pruned-live   the depthwise form: four all-zero filters whose bias lands on an
     *                    INTERIOR byte, so the constant is written, not saturated;
     *   dw-deadlive-rail pruned channels whose filters are NOT zero (taps in [-2, 2]) and
     *                    whose bias drives the whole reachable range past the rail: a live
     *                    filter, a constant output, the shape EfficientDet-Lite0's refused
     *                    depthwise layers carry;
     *   dw-deadlive-mid  the same with the range inside one interior byte;
     *   deep-live-1000x  a direct task of 32 whose fan-in caps the shift-0 C near 113, so a
     *                    1000x live spread clamps; under the shift C reaches 32767;
     *   dw-oc40 / oc40   a channel count that is not a multiple of the 16- or 32-channel
     *                    group, which moves the shift word's offset in both layouts;
     *   dw-70000x        a live channel below the field's floor even at C = 32767. */
    /* name            ic   oc  iw  ih  k  s pad  spread    dw dead dead_bias  rf rb dw_ zp in  out */
    { "dw-pruned-live",   64,  64, 16, 16, 3, 1, 1, 100.0f,   1, 4,  100000000, 1, 0, 0, 1,  5, -40 },
    { "dw-deadlive-rail", 64,  64, 16, 16, 3, 1, 1, 100.0f,   1, 6, -500000000, 1, 0, 2, 1, -100, 20 },
    { "dw-deadlive-mid",  64,  64, 16, 16, 3, 1, 1, 100.0f,   1, 6,  -50000000, 1, 0, 2, 1, -100, 20 },
    { "deep-live-1000x", 256,  32,  8,  8, 3, 1, 1, 1000.0f,  0, 0,          0, 1, 0, 0, 1,  3, -25 },
    { "dw-oc40",          40,  40, 12, 12, 3, 1, 1, 100.0f,   1, 0,          0, 0, 0, 0, 1, -20, 60 },
    { "oc40",             32,  40, 12, 12, 3, 1, 1, 100.0f,   0, 0,          0, 0, 0, 0, 1,  9, -90 },
    { "dw-70000x",        64,  64, 16, 16, 3, 1, 1, 70000.0f, 1, 0,          0, 1, 1, 0, 1, 12, 33 },
};
#define N_SHAPES ((int)(sizeof SHAPES / sizeof *SHAPES))

static void sleep_ms(int ms)
{
    struct timespec ts;
    if (ms <= 0) return;
    ts.tv_sec = ms / 1000;
    ts.tv_nsec = (long)(ms % 1000) * 1000000L;
    nanosleep(&ts, NULL);
}

/* The library sorts the output channels by scale so each tile spans as little of the
 * layer's scale range as the tiling allows. Bookkeeping, not the arithmetic under
 * test — mirrored here so the model reads the same slot the part did. */
static void sort_by_scale(unsigned *perm, unsigned oc, const float *w_scale)
{
    unsigned i, j;
    for (i = 0; i < oc; i++) perm[i] = i;
    for (i = 1; i < oc; i++) {
        unsigned v = perm[i];
        float s = w_scale[v];
        j = i;
        while (j > 0 && w_scale[perm[j - 1]] > s) { perm[j] = perm[j - 1]; j--; }
        perm[j] = v;
    }
}

static int run_shape(int fd, const pc_shape *s, int verbose)
{
    unsigned ic = s->ic, oc = s->oc, iw = s->iw, ih = s->ih, k = s->k;
    unsigned st = s->stride, pad = s->pad;
    unsigned ow = (iw + 2 * pad - k) / st + 1;
    unsigned oh = (ih + 2 * pad - k) / st + 1;
    int dw = s->dw;
    size_t in_n = (size_t)ic * ih * iw;
    size_t w_n = dw ? (size_t)oc * k * k : (size_t)oc * ic * k * k;
    size_t out_n = (size_t)oc * oh * ow;
    int8_t  *in = malloc(in_n), *W = malloc(w_n), *got = malloc(out_n);
    int8_t  *want = malloc(out_n);
    int32_t *bias = malloc(oc * sizeof *bias), *A = malloc(oc * sizeof *A);
    int64_t *sum_w = malloc(oc * sizeof *sum_w);
    int64_t *sum_abs_w = malloc(oc * sizeof *sum_abs_w);
    float   *w_scale = malloc(oc * sizeof *w_scale);
    int16_t *C = malloc(oc * sizeof *C);
    int32_t *Aslot = malloc(oc * sizeof *Aslot);
    unsigned *perm = malloc(oc * sizeof *perm);
    unsigned *slot_of = malloc(oc * sizeof *slot_of);
    unsigned *tile_mul = malloc(oc * sizeof *tile_mul);
    unsigned *tile_shift = malloc(oc * sizeof *tile_shift);
    rocket_conv2d_desc d = {0};
    const float in_scale = 0.021f, out_scale = 0.037f;
    const int in_zp = s->zp_set ? s->in_zp : -7, out_zp = s->zp_set ? s->out_zp : 11;
    const char *pcs = getenv("ROCKET_RK3576_PC_SHIFT");
    const int bs_mode = !(pcs && *pcs == '0');
    const int want_refuse = bs_mode ? s->refuse_bs : s->expect_refuse;
    int *cst = malloc(oc * sizeof *cst);
    unsigned *tile_bs = malloc(oc * sizeof *tile_bs);
    unsigned bs_lo = 64, bs_hi = 0, nconst = 0;
    unsigned mul, shift, c, i, y, x, ky, kx;
    unsigned oc_tile = 0;
    unsigned seed = 0x2545F491u ^ (ic * 31 + oc * 17 + iw * 7 + k);
    int exact = 0, worst = 0, rc, fail = 0;
    double ref_worst = 0.0, ref_sum = 0.0, dead_worst = 0.0;

    if (!in || !W || !got || !want || !bias || !A || !sum_w || !sum_abs_w ||
        !w_scale || !C || !Aslot || !perm || !slot_of || !tile_mul || !tile_shift ||
        !cst || !tile_bs) {
        fail = 1; goto done;
    }

    for (i = 0; i < in_n; i++) {
        seed = seed * 1103515245u + 12345u;
        in[i] = (int8_t)((int)((seed >> 16) % 255u) - 127);
    }
    for (i = 0; i < w_n; i++) {
        seed = seed * 1103515245u + 12345u;
        W[i] = (int8_t)((int)((seed >> 16) % 255u) - 127);
    }
    for (c = 0; c < oc; c++) {
        seed = seed * 1103515245u + 12345u;
        bias[c] = (int32_t)((int)((seed >> 16) % 2001u) - 1000);
        /* A geometric ramp across the spread: a per-axis model's scales are the
         * per-channel weight maxima, which do not vary linearly. */
        w_scale[c] = (float)(0.0009 *
            pow((double)s->spread, oc > 1 ? (double)c / (double)(oc - 1) : 0.0));
    }
    /* The pruned channels, written over the draw above. TFLite's own floor for an
     * all-zero tensor is 1e-6, and the filter is zeroed rather than made small: a
     * channel with no live weight reaches ONE accumulator. */
    for (c = oc - s->dead; c < oc && s->dead; c++) {
        size_t base = dw ? (size_t)c * k * k : (size_t)c * ic * k * k;
        size_t n_w  = dw ? (size_t)k * k : (size_t)ic * k * k;
        memset(W + base, 0, n_w);
        if (s->dead_w) {
            size_t t;
            for (t = 0; t < n_w; t++) {
                seed = seed * 1103515245u + 12345u;
                W[base + t] = (int8_t)((int)((seed >> 16) % (2u * s->dead_w + 1u)) -
                                       s->dead_w);
            }
            W[base] = (int8_t)s->dead_w;          /* never an all-zero filter */
        }
        w_scale[c] = 1e-6f;
        bias[c] = s->dead_bias;
    }

    d.ic = (int)ic; d.oc = (int)oc;
    d.ih = (int)ih; d.iw = (int)iw;
    d.kh = (int)k;  d.kw = (int)k;
    d.stride_y = (int)st; d.stride_x = (int)st;
    d.pad_top = (int)pad; d.pad_left = (int)pad;
    d.dil_y = 1; d.dil_x = 1;
    d.depthwise = dw;
    /* Exactly what a frontend hands a narrow per-axis convolution: the packed-image first
     * conv refuses a per-axis quantization, so the ordinary encoding is the only route and
     * the flag says so rather than letting the entry route by channel count. */
    d.direct_datapath = (!dw && ic <= 4) ? 1 : 0;

    /* THE PRUNED-CHANNEL CELLS ARE ABOUT A KNOB, so they set it EXPLICITLY IN BOTH
     * DIRECTIONS rather than relying on the default — the acceptance ships ON now, and a
     * cell that reads the default asserts whatever the default happens to be rather than
     * the behaviour it was written for. The refusing half runs with it ON too: what it
     * asserts is that the rule refuses a clamp that reaches the surface even when enabled. */
    setenv("ROCKET_RK3576_PC_INERT", s->dead ? "1" : "0", 1);

    /* The tile is bookkeeping — one task, one OUT_CVT shift — not the arithmetic
     * under test, so the model asks the library where it split rather than
     * re-deriving a CBUF rule. Everything downstream of it is modelled independently. */
    /* A cell whose pruned channels' clamp REACHES the surface asserts the refusal and
     * nothing else — there is no surface to score, and one computed anyway would be the
     * defect this refuses. The pair's other half is what says the refusal is not simply
     * refusing everything with a clamp in it. */
    if (want_refuse) {
        rc = rocket_conv2d_int8_perchannel_rk3576(fd, &d, in, W, bias, in_scale,
                                                  w_scale, out_scale, in_zp, out_zp, got);
        fail = (rc != ROCKET_E_UNSUPPORTED);
        printf("  %-4s %-11s ic=%-4u oc=%-4u %2ux%-2u k%u s%u  a channel whose clamp "
               "reaches the surface (%s ramp): returned %d, wanted %d\n",
               fail ? "FAIL" : "PASS", s->name, ic, oc, iw, ih, k, st,
               bs_mode ? "shift" : "shift-0", rc, ROCKET_E_UNSUPPORTED);
        goto done;
    }

    oc_tile = rocket_conv2d_int8_perchannel_oc_tile_rk3576(&d, W, bias, in_scale,
                                                           w_scale, out_scale, in_zp,
                                                           out_zp);
    if (!oc_tile) {
        printf("  %-11s ic=%-4u oc=%-4u  the entry refuses this descriptor\n",
               s->name, ic, oc);
        fail = 1; goto done;
    }
    rc = rocket_conv2d_int8_perchannel_rk3576(fd, &d, in, W, bias, in_scale,
                                              w_scale, out_scale, in_zp, out_zp, got);
    if (rc != ROCKET_OK) {
        printf("  %-11s ic=%-4u oc=%-4u %2ux%-2u k%u s%u  returned %d\n",
               s->name, ic, oc, iw, ih, k, st, rc);
        fail = 1; goto done;
    }

    /* The model. Same folds the library does, then the same planner, then the DPU's
     * epilogue in the order the part was measured to apply it. */
    for (c = 0; c < oc; c++) {
        int64_t sw = 0, sa = 0;
        if (dw) {
            for (ky = 0; ky < k; ky++)
                for (kx = 0; kx < k; kx++) {
                    int64_t v = W[((size_t)c * k + ky) * k + kx];
                    sw += v; sa += v < 0 ? -v : v;
                }
        } else {
            for (i = 0; i < ic; i++)
                for (ky = 0; ky < k; ky++)
                    for (kx = 0; kx < k; kx++) {
                        int64_t v = W[(((size_t)c * ic + i) * k + ky) * k + kx];
                        sw += v; sa += v < 0 ? -v : v;
                    }
        }
        sum_w[c] = sw; sum_abs_w[c] = sa;
        A[c] = (int32_t)((int64_t)bias[c] - (int64_t)in_zp * sw);
    }
    /* Depthwise binds output channel c to INPUT channel c, so the library cannot
     * reorder the output channels and does not try: the model reads the coefficient
     * slots in natural order there. */
    if (dw) { for (i = 0; i < oc; i++) perm[i] = i; }
    else    sort_by_scale(perm, oc, w_scale);
    /* A and C are per SLOT, in the permuted order the library packs the coefficient
     * group in, so the model builds both that way and maps back through slot_of. */
    for (i = 0; i < oc; i++) {
        unsigned cc = perm[i];
        Aslot[i] = (int32_t)((int64_t)bias[cc] - (int64_t)in_zp * sum_w[cc]);
        slot_of[cc] = i;
    }
    for (i = 0; i < oc; i += oc_tile) {
        unsigned n = oc - i < oc_tile ? oc - i : oc_tile, j, bs = 0;
        if (bs_mode)
            nconst += plan_c_bs(i, n, perm, sum_w, sum_abs_w, Aslot, in_scale, w_scale,
                                out_scale, out_zp, C, cst, &mul, &shift, &bs);
        else {
            plan_c(i, n, perm, sum_abs_w, Aslot, in_scale, w_scale, out_scale,
                   C, &mul, &shift);
            for (j = 0; j < n; j++) cst[i + j] = PC_MODEL_LIVE;
        }
        if (bs < bs_lo) bs_lo = bs;
        if (bs > bs_hi) bs_hi = bs;
        /* one OUT_CVT pair and one shift word per tile, recorded against its channels */
        for (j = 0; j < n; j++) {
            tile_mul[perm[i + j]]   = mul;
            tile_shift[perm[i + j]] = shift;
            tile_bs[perm[i + j]]    = bs;
        }
    }

    for (c = 0; c < oc; c++) {
        for (y = 0; y < oh; y++) {
            for (x = 0; x < ow; x++) {
                int64_t acc = 0;
                double  ref;
                int m;
                for (i = dw ? c : 0; i < (dw ? c + 1 : ic); i++)
                    for (ky = 0; ky < k; ky++)
                        for (kx = 0; kx < k; kx++) {
                            long iy = (long)(y * st + ky) - (long)pad;
                            long ix = (long)(x * st + kx) - (long)pad;
                            int8_t fv;
                            if (iy < 0 || ix < 0 || iy >= (long)ih || ix >= (long)iw)
                                fv = (int8_t)in_zp;      /* the emitter's border constant */
                            else
                                fv = in[((size_t)i * ih + (size_t)iy) * iw + (size_t)ix];
                            acc += (int64_t)fv *
                                   (dw ? W[((size_t)c * k + ky) * k + kx]
                                       : W[(((size_t)c * ic + i) * k + ky) * k + kx]);
                        }
                acc -= (int64_t)in_zp * sum_w[c];
                acc += bias[c];
                /* A constant channel is held to its exact byte; a live one to the part's
                 * epilogue, the BS shift's rounding included. */
                if (cst[slot_of[c]] != PC_MODEL_LIVE) m = cst[slot_of[c]];
                else m = epilogue_bs(acc, C[slot_of[c]], tile_bs[c], tile_mul[c],
                                     tile_shift[c], out_zp);
                want[((size_t)c * oh + y) * ow + x] = (int8_t)m;

                /* and what an exact per-axis requant would have produced */
                ref = (double)acc * (double)in_scale * (double)w_scale[c] /
                      (double)out_scale + (double)out_zp;
                if (ref >  127.0) ref =  127.0;
                if (ref < -128.0) ref = -128.0;
                {
                    double e = fabs(ref - (double)got[((size_t)c * oh + y) * ow + x]);
                    if (e > ref_worst) ref_worst = e;
                    ref_sum += e;
                    /* On a PRUNED channel the distance to an exact per-axis requant is
                     * ASSERTED and not reported: that is the whole claim the layer was
                     * accepted on, and it is the one number a bit-exact comparison
                     * against the chip's own arithmetic cannot make. */
                    if (((s->dead && c >= oc - s->dead) ||
                         cst[slot_of[c]] != PC_MODEL_LIVE) && e > dead_worst) dead_worst = e;
                }
            }
        }
    }

    for (i = 0; i < out_n; i++) {
        int diff = got[i] - want[i];
        if (diff < 0) diff = -diff;
        if (!diff) exact++;
        else if (diff > worst) worst = diff;
    }
    if (exact != (int)out_n) fail = 1;
    if (dead_worst > 0.5) fail = 1;

    printf("  %-4s %-11s ic=%-4u oc=%-4u %2ux%-2u k%u s%u  %7d/%-7zu  "
           "C[%d..%d] tile=%-4u vs exact per-axis: max %.1f mean %.2f",
           fail ? "FAIL" : "PASS", s->name, ic, oc, iw, ih, k, st,
           exact, out_n, C[0], C[oc - 1], oc_tile,
           ref_worst, ref_sum / (double)out_n);
    if (bs_mode)
        printf("  [BS shift %u..%u, %u constant channel(s), exact-per-axis distance on "
               "them %.2f]", bs_lo, bs_hi, nconst, dead_worst);
    else if (s->dead)
        printf("  [%u pruned, clamp inert, exact-per-axis distance on them %.1f]",
               s->dead, dead_worst);
    printf("\n");
    if (fail && verbose) {
        int shown = 0;
        for (i = 0; i < out_n && shown < 8; i++)
            if (got[i] != want[i]) {
                printf("      [%zu] chip model %d, part %d\n",
                       (size_t)i, want[i], got[i]);
                shown++;
            }
    }
done:
    free(in); free(W); free(got); free(want); free(bias); free(A);
    free(sum_w); free(sum_abs_w); free(w_scale); free(C);
    free(Aslot); free(perm); free(slot_of); free(tile_mul); free(tile_shift);
    free(cst); free(tile_bs);
    return fail;
}

int main(int argc, char **argv)
{
    const struct rocket_hw_profile *hw = rocket_hw_current();
    int fd, i, fails = 0, ran = 0;
    int verbose = getenv("ROCKET_PC_VERBOSE") != NULL;
    int gap = getenv("ROCKET_PC_GAP_MS") ? atoi(getenv("ROCKET_PC_GAP_MS")) : 0;

    if (strcmp(hw->name, "rk3576") != 0) {
        printf("rk3576_perchannel_gate: profile is %s, not rk3576 — skipping\n",
               hw->name);
        return 2;
    }
    fd = rocket_open();
    if (fd < 0) { printf("rk3576_perchannel_gate: no NPU device — skipping\n"); return 2; }

    printf("== RK3576 per-output-channel int8 conv ==\n");
    printf("   bit-exact against the CHIP's arithmetic; the distance to an exact "
           "per-axis requant is reported, not gated\n");
    for (i = 0; i < N_SHAPES; i++) {
        if (argc > 1 && !strstr(SHAPES[i].name, argv[1])) continue;
        sleep_ms(gap);
        fails += run_shape(fd, &SHAPES[i], verbose);
        ran++;
    }
    rocket_close(fd);
    printf("== %d passed, %d failed ==\n", ran - fails, fails);
    return fails ? 1 : 0;
}
