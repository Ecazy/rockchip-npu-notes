// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 The rocket-userspace authors
/*
 * uapi_selftest_rocket.c — runtime conformance probe for the mainline rocket
 * DRM-accel uAPI. It checks the drm_rocket_* contracts the whole library
 * leans on, so a kernel that drifts (a new SoC port, a uAPI revision, a distro
 * kernel) fails HERE with a named diagnostic instead of silently mis-waiting or
 * mis-addressing deep in the matmul path.
 *
 * What it pins, and why each matters:
 *   1. Driver identity + version           — the shim only speaks "rocket".
 *   2. CREATE_BO contract                   — handle/ptr/dma_address valid, BO
 *      + 32-bit regcmd IOVA window            page-aligned, and the FIRST BO sits
 *                                             in the low 4 GB (the NPU PC's
 *                                             BASE_ADDRESS reg is 32-bit; a regcmd
 *                                             BO above 4 GB silently hangs).
 *   3. PREP/FINI cache round-trip           — rocket BOs are cached; a write that
 *                                             survives fini->prep proves the sync.
 *   4. PREP_BO DEADLINE SEMANTICS           — the load-bearing footgun: the kernel
 *      (the cross-kernel canary)              runs timeout_ns through
 *                                             drm_timeout_abs_to_jiffies() => it is
 *                                             an ABSOLUTE CLOCK_MONOTONIC deadline,
 *                                             NOT a duration. The shim converts a
 *                                             relative timeout to absolute; if a
 *                                             kernel changed this, every job wait
 *                                             would degrade to an immediate -EBUSY
 *                                             poll. We verify both directions on a
 *                                             real in-flight job — an fp16 matmul
 *                                             where that generator has an encoder,
 *                                             and a 1x1 int8 convolution where it
 *                                             does not, so the guard covers every
 *                                             kernel the library submits to.
 *   5. IOVA growth report                   — where successive BOs land (per-fd
 *                                             window); informational.
 *
 * This is a GATE (registered in CTest): exit 0 = all required checks pass, 1 =
 * a required check failed, 2 = no NPU device (skip). The deadline canary's
 * "job already finished" branch is informational, never a failure.
 *
 * Build: linked against rocketnpu by CMake. Run: ./uapi_selftest_rocket
 */
#define _GNU_SOURCE
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <sys/ioctl.h>

#include <drm/rocket_accel.h>   /* raw DRM_IOCTL_ROCKET_* for the deadline canary */

#include "rocket_npu.h"
#include "npu_matmul.h"
#include "rocket_hw_profile.h"      /* to pick the program this part runs */
#include "npu_regcmd_rk3576.h"      /* the RK3576's own conv generator    */

static int fails = 0, checks = 0;
#define CHECK(cond, msg) do { checks++; if (cond) { printf("  ok   : %s\n", msg); } \
    else { printf("  FAIL : %s\n", msg); fails++; } } while (0)
#define INFO(...) do { printf("  info : "); printf(__VA_ARGS__); printf("\n"); } while (0)

static int64_t mono_ns(void){ struct timespec ts; clock_gettime(CLOCK_MONOTONIC,&ts);
    return (int64_t)ts.tv_sec*1000000000LL + ts.tv_nsec; }

/* The two deadline checks themselves, on a job that is ALREADY in flight. Factored
 * out because the regcmd in flight is per-chip and the contract under test is not:
 * timeout_ns is an absolute CLOCK_MONOTONIC deadline in every kernel, whatever
 * program the part happens to run. */
static void deadline_checks(int fd, rocket_bo *out, rocket_bo *in)
{
    /* (a) ABSOLUTE-deadline canary: a RAW PREP_BO with a deadline 1 ms IN THE PAST.
     * Absolute semantics => return promptly (not hang); a non-zero errno means the
     * fence is unsignalled (job in flight) — the expected, healthy reading. A
     * relative-duration kernel would instead WAIT ~0 and is indistinguishable here,
     * so this branch is informational; check (b) is the hard regression guard. */
    struct drm_rocket_prep_bo past = { .handle = out->handle,
        .timeout_ns = mono_ns() - 1000000LL /* 1 ms ago */ };
    int64_t t0 = mono_ns();
    int prc = ioctl(fd, DRM_IOCTL_ROCKET_PREP_BO, &past);
    int64_t dt = mono_ns() - t0;
    int e = prc < 0 ? errno : 0;
    CHECK(dt < 500000000LL, "raw PREP_BO with a PAST absolute deadline returns promptly (no hang)");
    if (prc < 0) INFO("  past-deadline poll -> errno %d (%s) = fence unsignalled, job in-flight",
                      e, strerror(e));
    else         INFO("  past-deadline poll -> 0 (job already completed; canary inconclusive)");

    /* (b) HARD GUARD: the shim's relative->absolute conversion must let a generous
     * relative wait actually complete the job. If the conversion regressed (passing
     * a raw small value as absolute), the kernel would see a past deadline and
     * return -EBUSY even though the job finishes fine. */
    int wrc = rocket_bo_prep(fd, out, 0, 3000000000LL /* 3 s relative */);
    CHECK(wrc == 0, "shim PREP_BO (relative 3s) completes the in-flight job (abs-deadline conversion OK)");
    rocket_bo_fini(fd, out);

    /* FINI_BO must always succeed. */
    CHECK(rocket_bo_fini(fd, in) == 0, "FINI_BO succeeds");
}

/* The canary's RK3576 job. gen_matmul_fp16() refuses on this part — its
 * geometry-register encoding is re-packed and the fp16 matmul has no encoder here —
 * so the canary builds what the part DOES run: a 1x1 int8 convolution, which is the
 * same thing a matmul is on this hardware. The arithmetic is irrelevant (the cubes
 * are left zeroed); what the check needs is a well-formed program that occupies the
 * NPU long enough to be caught in flight, and int8 output is the one width that does
 * not poison the next submit.
 *
 * Returns 1 if a job was submitted and the checks ran, 0 if the part could not build
 * one (never a failure — that is a fact about the encoder, not about the uAPI). */
static int conv_canary(int fd)
{
    /* Small enough to be safely inside the envelope on every axis the emitter bounds
     * (ic and oc multiples of 32, iw a multiple of 16, one row window), big enough
     * that the job outlives the submit ioctl. */
    const unsigned IC = 32, OC = 32, IW = 32, IH = 32;
    rocket_bo in = {0}, wt = {0}, coeff = {0}, rc_bo = {0}, out = {0};
    uint64_t ops[RK3576_CONV_TASK_OPS] = {0};
    rocket_bo *all[] = { &in, &wt, &coeff, &rc_bo, &out };
    size_t feat = (size_t)IC * IH * IW;
    size_t surf = (size_t)OC * rocket_rk3576_out_surf_elems(IW, IH, 0);
    int ran = 0;

    if (rocket_bo_alloc(fd, feat, &in) || rocket_bo_alloc(fd, (size_t)OC * IC, &wt) ||
        rocket_bo_alloc(fd, rocket_rk3576_coeff_bytes(OC), &coeff) ||
        rocket_bo_alloc(fd, sizeof ops, &rc_bo) || rocket_bo_alloc(fd, surf, &out)) {
        INFO("could not allocate the conv canary's BOs (skip)");
        goto done;
    }

    conv_params_t p = {
        .ic = IC, .ih = IH, .iw = IW, .oc = OC, .oh = IH, .ow = IW,
        .kh = 1, .kw = 1, .stride_y = 1, .stride_x = 1, .dil_y = 1, .dil_x = 1,
        .ih_full = IH, .oh_full = IH, .int8_out = 1, .tasks = ops,
        .in_scale = 1.0f, .w_scale = 1.0f, .out_scale = 1.0f,
        .input_dma   = (uint32_t)in.dma_address,
        .weights_dma = (uint32_t)wt.dma_address,
        .bias_dma    = (uint32_t)coeff.dma_address,
        .output_dma  = (uint32_t)out.dma_address,
    };
    if (gen_conv2d_int8_rk3576(&p) != 0 || p.task_count == 0) {
        INFO("the part's int8 conv generator refused too: canary skipped");
        goto done;
    }

    rocket_bo_prep(fd, &rc_bo, 1, 0);
    memcpy(rc_bo.ptr, ops, p.task_count * sizeof(uint64_t));
    rocket_bo_fini(fd, &rc_bo);

    INFO("canary job: a %ux%ux%u 1x1 int8 conv, %u regcmd ops", IC, IH, IW, p.task_count);
    rocket_task_desc t = { (uint32_t)rc_bo.dma_address, p.task_count };
    uint32_t inh[] = { in.handle, wt.handle, coeff.handle, rc_bo.handle };
    uint32_t outh[] = { out.handle };
    if (rocket_submit_tasks(fd, &t, 1, inh, 4, outh, 1)) {
        CHECK(0, "rocket_submit_tasks (async job)");
        goto done;
    }
    deadline_checks(fd, &out, &in);
    ran = 1;

done:
    for (unsigned i = 0; i < sizeof all / sizeof all[0]; i++)
        if (all[i]->handle) rocket_bo_free(fd, all[i]);
    return ran;
}

/* DRM_IOCTL_VERSION lives in <drm/drm.h>, pulled in by rocket_accel.h. */
#include <drm/drm.h>

int main(void)
{
    int fd = rocket_open();
    if (fd < 0) { fprintf(stderr, "no rocket device (skip)\n"); return 2; }

    printf("== rocket uAPI self-test ==\n");

    /* 1. Driver identity + version --------------------------------------- */
    {
        char name[32] = {0};
        struct drm_version dv = { .name = name, .name_len = sizeof(name)-1 };
        int rc = ioctl(fd, DRM_IOCTL_VERSION, &dv);
        CHECK(rc == 0, "DRM_IOCTL_VERSION");
        CHECK(rc == 0 && strcmp(name, "rocket") == 0, "driver name == \"rocket\"");
        INFO("driver \"%s\" v%d.%d.%d", name, dv.version_major, dv.version_minor,
             dv.version_patchlevel);
    }

    /* 2. CREATE_BO contract + 32-bit regcmd window ----------------------- */
    rocket_bo b0 = {0};
    {
        int rc = rocket_bo_alloc(fd, 1000, &b0);   /* deliberately non-page-multiple */
        CHECK(rc == 0, "CREATE_BO(1000) succeeds");
        CHECK(rc == 0 && b0.handle != 0,       "BO handle non-zero");
        CHECK(rc == 0 && b0.ptr != NULL,       "BO mmap pointer valid");
        /* NPU FACT: the per-fd IOVA allocator BUMP-STARTS AT 0, so the FIRST BO on a
         * fresh fd legitimately gets dma_address == 0x0. dma_address is therefore NOT
         * a validity sentinel — handle/ptr are. The real invariants are page-alignment
         * and the 32-bit regcmd window. */
        CHECK(rc == 0 && (b0.dma_address & 0xFFF) == 0,
              "BO dma_address page-aligned (kernel rounds size to a page)");
        /* The regcmd BO must live below 4 GB (32-bit NPU PC BASE_ADDRESS). */
        CHECK(rc == 0 && (b0.dma_address >> 32) == 0,
              "first BO in low 4 GB (regcmd-addressable IOVA window)");
        if (b0.dma_address == 0)
            INFO("dma_address = 0x0 (allocator bump-starts at 0 — a VALID IOVA, not an error)");
        else
            INFO("dma_address = 0x%llx", (unsigned long long)b0.dma_address);
    }

    /* 3. PREP/FINI cache round-trip -------------------------------------- */
    if (b0.ptr) {
        rocket_bo_prep(fd, &b0, 1, 0);            /* own for CPU write */
        for (int i = 0; i < 250; i++) ((uint8_t*)b0.ptr)[i] = (uint8_t)(i*7+3);
        rocket_bo_fini(fd, &b0);                  /* flush for device   */
        rocket_bo_prep(fd, &b0, 0, 0);            /* invalidate for CPU read */
        int intact = 1;
        for (int i = 0; i < 250; i++) if (((uint8_t*)b0.ptr)[i] != (uint8_t)(i*7+3)) intact = 0;
        CHECK(intact, "PREP/FINI cache-sync preserves a CPU-written pattern");
        rocket_bo_fini(fd, &b0);
    }

    /* 4. PREP_BO deadline semantics on a REAL in-flight job --------------- */
    {
        const int M = 64, K = 64, N = 64;
        const int NTASK = 512;   /* enough tasks that the job is briefly in-flight */
        rocket_bo in={0}, wt={0}, rc_bo={0}, out={0};
        size_t in_sz=(size_t)M*K*sizeof(_Float16)+4096,
               wt_sz=(size_t)N*K*sizeof(_Float16)+4096,
               out_sz=(size_t)M*N*sizeof(_Float16)+4096;
        int ok = !rocket_bo_alloc(fd,in_sz,&in) && !rocket_bo_alloc(fd,wt_sz,&wt) &&
                 !rocket_bo_alloc(fd,512*sizeof(uint64_t),&rc_bo) &&
                 !rocket_bo_alloc(fd,out_sz,&out);
        CHECK(ok, "alloc job BOs (in/wt/regcmd/out)");
        if (ok) {
            rocket_bo_prep(fd,&in,1,0);  memset(in.ptr,0,in.size);
            for(int h=1;h<=M;h++) for(int c=1;c<=K;c++)
                ((_Float16*)in.ptr)[feature_data(K,M,1,8,c,h,1)]=(_Float16)(0.01f*((h+c)%7));
            rocket_bo_fini(fd,&in);
            rocket_bo_prep(fd,&wt,1,0);  memset(wt.ptr,0,wt.size);
            for(int k=1;k<=N;k++) for(int c=1;c<=K;c++)
                ((_Float16*)wt.ptr)[weight_fp16(K,k,c)]=(_Float16)(0.01f*((k*c)%5));
            rocket_bo_fini(fd,&wt);

            uint64_t ops[512]={0};
            matmul_params_t p={.m=M,.k=K,.n=N,.input_dma=(uint32_t)in.dma_address,
                .weights_dma=(uint32_t)wt.dma_address,.output_dma=(uint32_t)out.dma_address,
                .tasks=ops,.fp32tofp16=1};
            int genrc = gen_matmul_fp16(&p);

            /* The canary needs a REAL job in flight, and this datapath's generator
             * refuses on a part it has no encoder for (the RK3576 runs a re-packed
             * geometry-register encoding). Refusing is correct there, so it is not a
             * failure of the uAPI — but the tasks below must not be submitted anyway.
             * A task with regcmd_count == 0 is one of the malformed submits that a
             * kernel without the rocket_job_cleanup NULL-domain fix OOPSES on
             * (see uapi_submit_errpath_rocket), so building the job from a refused
             * generate would crash the box it is meant to be conformance-testing. */
            const int have_regcmd = (genrc == 0 && p.task_count > 0);
            if (!have_regcmd) {
                INFO("gen_matmul_fp16 refused on this part (%s): the canary needs a "
                     "regcmd this part RUNS, so it builds a 1x1 int8 conv instead",
                     rocket_hw_current()->name);
                conv_canary(fd);
            } else {
            CHECK(genrc == 0, "gen_matmul_fp16 (build a real regcmd)");
            rocket_bo_prep(fd,&rc_bo,1,0); memcpy(rc_bo.ptr,ops,p.task_count*sizeof(uint64_t));
            rocket_bo_fini(fd,&rc_bo);

            rocket_task_desc tasks[512];
            for(int i=0;i<NTASK;i++) tasks[i]=(rocket_task_desc){(uint32_t)rc_bo.dma_address,p.task_count};
            uint32_t inh[]={in.handle,wt.handle,rc_bo.handle}, outh[]={out.handle};

            if (!rocket_submit_tasks(fd,tasks,NTASK,inh,3,outh,1))
                deadline_checks(fd, &out, &in);
            else
                CHECK(0, "rocket_submit_tasks (async job)");
            }   /* have_regcmd */
        }
        rocket_bo_free(fd,&in); rocket_bo_free(fd,&wt);
        rocket_bo_free(fd,&rc_bo); rocket_bo_free(fd,&out);
    }

    /* 6. EXTENSIBLE-STRUCT uAPI CONTRACT --------------------------------
     *
     * drm_rocket_job / drm_rocket_task carry @job_struct_size / @task_struct_size
     * so the descriptors can GROW: userspace declares the size it was built
     * against, and the kernel must accept anything from the original ("v1")
     * layout upward. A kernel that instead compares against its own sizeof()
     * rejects every older userspace the moment a field is appended.
     *
     * That is not hypothetical. A uAPI header carrying drm_rocket_job.flags,
     * installed against a driver whose code did not implement it, rejected every
     * submit from a userspace built on the older header with -EINVAL -- which is
     * what made matmul_int8_dequant_rocket "require" the batched-submit patch
     * (2026-07-14). These checks fail loudly in exactly that configuration.
     *
     * The v1 sizes are header-independent by construction: offsetofend() of the
     * last ORIGINAL field, which no appended field can move.
     *
     * The probe job below is well-formed EXCEPT for a deliberately invalid BO
     * handle, so it can never reach the NPU, and a size rejection (-EINVAL) stays
     * distinguishable from the job-level rejection (-ENOENT / 0).
     */
    {
        const size_t job_v1  = offsetof(struct drm_rocket_job, out_bo_handle_count) +
                               sizeof(((struct drm_rocket_job *)0)->out_bo_handle_count);
        const size_t task_v1 = offsetof(struct drm_rocket_task, regcmd_count) +
                               sizeof(((struct drm_rocket_task *)0)->regcmd_count);

        char vname[32] = {0};
        struct drm_version dv = { .name = vname, .name_len = sizeof(vname)-1 };
        ioctl(fd, DRM_IOCTL_VERSION, &dv);
        const int extensible = (dv.version_major >= 1);              /* >= 1.0 */
        const int has_flags  = (dv.version_major > 1 ||
                                (dv.version_major == 1 && dv.version_minor >= 1));

        /* Every check here SUBMITS a deliberately-malformed job. Only a driver
         * advertising the contract (>= 1.0) is safe to probe this way: the same
         * patch that added the extensible-struct handling also fixed the latent
         * rocket_iommu_domain_put() NULL deref that a rejected submit walks into,
         * so a pre-1.0 kernel would OOPS rather than return an errno. Skip the
         * submits there -- userspace already refuses to rely on the contract when
         * the driver does not advertise it. */
        if (!extensible) {
            INFO("driver %d.%d predates the extensible-struct contract (< 1.0): "
                 "submit-based contract checks skipped (would oops a pre-fix kernel)",
                 dv.version_major, dv.version_minor);
        } else {
        uint32_t bogus[1] = { 0xFFFFFFF0u };   /* no such GEM handle => -ENOENT */
        struct drm_rocket_task t = { .regcmd = 0, .regcmd_count = 1 };
        struct drm_rocket_job  j = {
            .tasks               = (uint64_t)(uintptr_t)&t,
            .task_count          = 1,
            .task_struct_size    = (uint32_t)task_v1,
            .in_bo_handles       = (uint64_t)(uintptr_t)bogus,
            .in_bo_handle_count  = 1,
            .out_bo_handles      = (uint64_t)(uintptr_t)bogus,
            .out_bo_handle_count = 1,
        };
        struct drm_rocket_submit s = {
            .jobs = (uint64_t)(uintptr_t)&j, .job_count = 1,
            .job_struct_size = (uint32_t)job_v1,
        };

        /* (a) THE REGRESSION CHECK: a v1-sized declaration must never be rejected
         *     for being too small. The job still fails (bad handle), but it must
         *     not fail at the SIZE gate. */
        errno = 0;
        int rc = ioctl(fd, DRM_IOCTL_ROCKET_SUBMIT, &s);
        int e  = errno;
        CHECK(!(rc < 0 && e == EINVAL),
              "job_struct_size = the v1 minimum is accepted (extensible-struct "
              "contract; a kernel whose struct grew but kept the '< sizeof' guard "
              "fails HERE with -EINVAL)");
        INFO("driver %d.%d, job v1=%zu sizeof=%zu -> rc=%d (%s)",
             dv.version_major, dv.version_minor, job_v1,
             sizeof(struct drm_rocket_job), rc, rc ? strerror(e) : "accepted");

        /* (b) Below the v1 minimum must still be refused. */
        struct drm_rocket_submit s_short = s;
        s_short.job_struct_size = (uint32_t)(job_v1 - 4);
        errno = 0;
        CHECK(ioctl(fd, DRM_IOCTL_ROCKET_SUBMIT, &s_short) < 0 && errno == EINVAL,
              "job_struct_size below the v1 minimum is rejected (-EINVAL)");

        {
            /* (c) Same contract for the task descriptor -- the struct the original
             *     batched-submit patch left with a strict sizeof() guard. */
            struct drm_rocket_job j_bt = j;
            j_bt.task_struct_size = (uint32_t)(task_v1 - 4);
            struct drm_rocket_submit s_bt = s;
            s_bt.jobs = (uint64_t)(uintptr_t)&j_bt;
            errno = 0;
            CHECK(ioctl(fd, DRM_IOCTL_ROCKET_SUBMIT, &s_bt) < 0 && errno == EINVAL,
                  "task_struct_size below the v1 minimum is rejected (-EINVAL)");

            /* (d) A trailing field this kernel does not know, SET by userspace,
             *     must be refused loudly rather than silently dropped -- otherwise
             *     the job runs with semantics nobody asked for. */
            struct { struct drm_rocket_job job; uint32_t tail[8]; } big = { .job = j };
            big.tail[7] = 0xDEADBEEFu;
            struct drm_rocket_submit s_big = {
                .jobs = (uint64_t)(uintptr_t)&big, .job_count = 1,
                .job_struct_size = (uint32_t)sizeof(big),
            };
            errno = 0;
            CHECK(ioctl(fd, DRM_IOCTL_ROCKET_SUBMIT, &s_big) < 0 && errno == E2BIG,
                  "a trailing field the kernel does not know, set by userspace, is "
                  "refused with -E2BIG (never silently ignored)");
        }

        /* (e) Unknown flag bits must be rejected, so a future flag cannot be
         *     silently ignored by a kernel that does not implement it. */
        if (has_flags) {
            /* Written by OFFSET, not through the struct: the installed header may
             * predate @flags, and @flags sits exactly at the v1 end by definition. */
            unsigned char jb[128] = {0};
            uint32_t bad_flag = 0x80000000u;     /* no such flag */
            memcpy(jb, &j, job_v1);
            memcpy(jb + job_v1, &bad_flag, sizeof(bad_flag));   /* @flags    */
                                                                /* @reserved stays 0 */
            struct drm_rocket_submit s_bf = {
                .jobs = (uint64_t)(uintptr_t)jb, .job_count = 1,
                .job_struct_size = (uint32_t)(job_v1 + 8),
            };
            errno = 0;
            CHECK(ioctl(fd, DRM_IOCTL_ROCKET_SUBMIT, &s_bf) < 0 && errno == EINVAL,
                  "an unknown drm_rocket_job.flags bit is rejected (-EINVAL)");
        }

        /* Chaining is a joint layout contract: if the kernel would ignore the
         * flag, userspace must not self-chain. Pin that the library agrees with
         * what the driver advertises. */
        CHECK(rocket_batched_submit_supported() == 0 || has_flags,
              "library enables chained submit only on a driver that honors "
              "DRM_ROCKET_JOB_BATCHED (>= 1.1)");
        }  /* extensible */
    }

    /* 5. IOVA growth report (informational) ------------------------------ */
    {
        rocket_bo bos[8]; int n=0; int all_low=1; int monotonic=1;
        uint64_t lo=~0ULL, hi=0, prev=0;
        for (; n<8; n++) {
            if (rocket_bo_alloc(fd, 1<<20, &bos[n])) break;
            uint64_t a = bos[n].dma_address;
            if (a < lo) lo = a;
            if (a + (1<<20) > hi) hi = a + (1<<20);
            if ((a>>32) != 0) all_low = 0;
            if (n > 0 && a <= prev) monotonic = 0;
            prev = a;
        }
        INFO("allocated %d x 1 MB; IOVA span [0x%llx .. 0x%llx], all<4GB=%d",
             n, (unsigned long long)lo, (unsigned long long)hi, all_low);
        CHECK(n > 0 && monotonic, "successive BOs get distinct ascending IOVAs (bump allocator)");
        for (int i=0;i<n;i++) rocket_bo_free(fd,&bos[i]);
    }

    rocket_bo_free(fd, &b0);
    rocket_close(fd);

    printf("== %d checks, %d failed ==\n", checks, fails);
    return fails ? 1 : 0;
}
