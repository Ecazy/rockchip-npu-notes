// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 The rocket-userspace authors
/*
 * rocket_npu.c — see rocket_npu.h.
 *
 * Targets the mainline DRM-accel "rocket" driver over /dev/accel/accel0, using the uAPI
 * from <drm/rocket_accel.h> (the DRM_IOCTL_ROCKET_* ioctls and struct drm_rocket_*). The
 * descriptor field names below follow that mainline header; build against the
 * <drm/rocket_accel.h> installed on the target kernel.
 */
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <stdlib.h>

#include <time.h>

#include <stddef.h>         /* offsetof */
#include <dirent.h>         /* the bound-core count */
#include <sys/stat.h>
#include <limits.h>         /* INT_MAX — a major above 1 outranks every known minor */
#include <stdatomic.h>      /* the cached capability probe */

#include <libdrm/drm.h>
#include <drm/rocket_accel.h>   /* DRM_IOCTL_ROCKET_*, struct drm_rocket_*    */

#include "rocket_npu.h"
#include "rocket_log.h"
#include "rocket_sysfs.h"        /* the one enumeration of the bound NPU cores */
#include "rocket_busy_poll.h"    /* the shared completion-wait spin budget    */
#include "rocket_fence_watch.h"   /* how long each fenced wait took            */
#include "rocket_rk3576_internal.h"   /* rocket_rk3576_bo_pool_drain, called from rocket_close */            // centralized log channel
#include "rocket_hw_profile.h"     // chip detection (warn on unprofiled silicon)

/*
 * Per-job batched-submit flag (DRM_ROCKET_JOB_BATCHED): runs a job's tasks as
 * one chained HW kick (see rocket_chain.c / the patches/rocket kernel half).
 * It is an OPTIONAL trailing field of drm_rocket_job. When the installed
 * <drm/rocket_accel.h> already carries it, set job.flags directly. When it
 * predates the field (e.g. an off-device syntax check against an unpatched
 * header), append the field via a wrapper at exactly the offset the kernel
 * expects (pinned by the static_assert). Either way the flag is a no-op against
 * a kernel that does not implement it.
 */
#ifndef DRM_ROCKET_JOB_BATCHED
#define DRM_ROCKET_JOB_BATCHED (1u << 0)
#define DRM_ROCKET_JOB_NO_DPU_DONE (1u << 1)
#define DRM_ROCKET_JOB_PPU_DONE (1u << 2)
struct rocket_job_flagged {
    struct drm_rocket_job job;
    __u32 flags;
    __u32 reserved;
};
_Static_assert(offsetof(struct rocket_job_flagged, flags) ==
               sizeof(struct drm_rocket_job),
               "appended flags must sit exactly at the stock drm_rocket_job end");
#define ROCKET_JOB_FLAGS_VENDORED 1
#endif
/* A header that has @flags but predates the completion-class bit. */
#ifndef DRM_ROCKET_JOB_NO_DPU_DONE
#define DRM_ROCKET_JOB_NO_DPU_DONE (1u << 1)
#endif
/* A header that has the completion-class bit but predates the PPU one. */
#ifndef DRM_ROCKET_JOB_PPU_DONE
#define DRM_ROCKET_JOB_PPU_DONE (1u << 2)
#endif
_Static_assert(ROCKET_JOB_BATCHED == DRM_ROCKET_JOB_BATCHED &&
               ROCKET_JOB_NO_DPU_DONE == DRM_ROCKET_JOB_NO_DPU_DONE &&
               ROCKET_JOB_PPU_DONE == DRM_ROCKET_JOB_PPU_DONE,
               "the library's ROCKET_JOB_* bits are passed to the kernel verbatim");

/*
 * rkt_job — the ABI-complete job struct: drm_rocket_job plus its trailing
 * @flags/@reserved, whether the installed header declares them or we append
 * them. EVERY submit site must build one of these and declare sizeof(rkt_job)
 * as job_struct_size, so the size we advertise never depends on which
 * <drm/rocket_accel.h> happens to be installed.
 *
 * Always sending the full struct is the compatible direction against both
 * kernels: one that predates @flags copies only the fields it knows and strides
 * past the tail, and one that has it reads flags == 0 -> the stock per-task
 * path. The REVERSE is not safe -- declaring the shorter, pre-@flags size to a
 * kernel whose drm_rocket_job has grown trips its "job_struct_size ... is too
 * small" guard and the submit fails with -EINVAL. (A kernel carrying the
 * uapi-extensible-structs patch guards on the v1 minimum instead and tolerates a
 * short declaration, but do not rely on that: declare what you have.) Both
 * @flags and @reserved are named identically in the vendored wrapper and the
 * native struct, so only the base fields need the accessor.
 *
 * Note this is only about the SIZE we declare. Whether the kernel HONORS the
 * batched flag is a separate question -- see rocket_batched_submit_supported().
 */
#ifdef ROCKET_JOB_FLAGS_VENDORED
typedef struct rocket_job_flagged rkt_job;
#define RKT_JOB_BASE(j) ((j).job)
#else
typedef struct drm_rocket_job rkt_job;
#define RKT_JOB_BASE(j) (j)
#endif

/* Fill one rkt_job. Zeroes the whole struct first so @reserved (and any field a
 * newer header adds) stays 0. */
static void rkt_job_init(rkt_job *j, struct drm_rocket_task *dt, uint32_t n_tasks,
                         const uint32_t *in_handles,  uint32_t n_in,
                         const uint32_t *out_handles, uint32_t n_out,
                         uint32_t job_flags)
{
    memset(j, 0, sizeof(*j));
    RKT_JOB_BASE(*j) = (struct drm_rocket_job){
        .tasks               = (uint64_t)(uintptr_t)dt,
        .task_count          = n_tasks,
        .task_struct_size    = sizeof(struct drm_rocket_task),
        .in_bo_handles       = (uint64_t)(uintptr_t)in_handles,
        .in_bo_handle_count  = n_in,
        .out_bo_handles      = (uint64_t)(uintptr_t)out_handles,
        .out_bo_handle_count = n_out,
    };
    j->flags = job_flags;
}

/* Every ROCKET_SUBMIT this process issues, and the tasks it carried. Counted at the
 * two ioctl sites so no caller can bypass them. See rocket_submit_ioctl_count().
 *
 * _Atomic because every fan-out path in this library submits from N worker threads at
 * once: a plain `++` from several of them drops counts, and these feed the benchmarks'
 * submits-per-inference. relaxed ordering is enough — nothing else is published through
 * them — so the cost is an LDADD next to an ioctl, i.e. nothing. */
static _Atomic uint64_t rkt_ioctl_submits;
static _Atomic uint64_t rkt_submitted_tasks;

static inline void rkt_count_submit(uint32_t n_tasks)
{
    atomic_fetch_add_explicit(&rkt_ioctl_submits, 1, memory_order_relaxed);
    atomic_fetch_add_explicit(&rkt_submitted_tasks, n_tasks, memory_order_relaxed);
}

uint64_t rocket_submit_ioctl_count(void)
{
    return atomic_load_explicit(&rkt_ioctl_submits, memory_order_relaxed);
}
uint64_t rocket_submit_task_count(void)
{
    return atomic_load_explicit(&rkt_submitted_tasks, memory_order_relaxed);
}
void rocket_submit_counters_reset(void)
{
    atomic_store_explicit(&rkt_ioctl_submits, 0, memory_order_relaxed);
    atomic_store_explicit(&rkt_submitted_tasks, 0, memory_order_relaxed);
}

/* Submit one job (n_tasks tasks) on `fd`, optionally with the per-job batched
 * flag set. Returns 0 / negative errno. */
static int rkt_submit_one_job(int fd, struct drm_rocket_task *dt, uint32_t n_tasks,
                              const uint32_t *in_handles,  uint32_t n_in,
                              const uint32_t *out_handles, uint32_t n_out,
                              uint32_t job_flags)
{
    rkt_job jx;
    rkt_job_init(&jx, dt, n_tasks, in_handles, n_in, out_handles, n_out, job_flags);

    struct drm_rocket_submit submit = {
        .jobs            = (uint64_t)(uintptr_t)&jx,
        .job_count       = 1,
        .job_struct_size = sizeof(jx),
    };
    rkt_count_submit(n_tasks);
    if (ioctl(fd, DRM_IOCTL_ROCKET_SUBMIT, &submit) < 0) {
        ROCKET_LOGE("ROCKET_SUBMIT(%u tasks, flags=0x%x): %s\n",
                    n_tasks, job_flags, strerror(errno));
        return -errno;
    }
    return 0;
}

/* ============================================================================
 * SECTION — Kernel capabilities
 * ==========================================================================*/

/* ── The DRM interface version, resolved ONCE ───────────────────────────────────
 *
 * Four capability probes below key on the minor number the kernel advertises. Each used
 * to answer by calling rocket_open(), which is wrong twice: it is four DRM client
 * open/close round trips per process for one unchanging number, and on an RK3576 whose
 * device tree enables core 1 — the stock configuration this file spends thirty lines
 * warning about — rocket_open() REFUSES a second fd while the library already holds one.
 * A probe that ran mid-flight therefore got -EBUSY, cached "unsupported" for the process
 * lifetime, and silently turned off three built and shipped levers (ranged cache sync,
 * PPU_DONE completion, the chained task cap) while logging a scary refusal from a call
 * site that submits nothing.
 *
 * So resolve it here, on a raw fd that never touches the multi-fd counter. Same device
 * selection and same driver-name check as rocket_open(), because a probe against some
 * other accel device must not report rocket's interface.
 *
 * Returns the minor number, or -1 if the device could not be identified as rocket.
 * Mainline reports 0.0.0; a major above 1 reads as "newer than everything we know". */
static int rocket_iface_minor(void)
{
    static _Atomic int cached = -2;                  /* -2 = unresolved, >= -1 = answer */
    int c = atomic_load(&cached);
    if (c >= -1)
        return c;

    c = -1;
    const char *dev = getenv("ROCKET_DEV");
    if (!dev || !*dev) dev = "/dev/accel/accel0";
    int fd = open(dev, O_RDWR | O_CLOEXEC);
    if (fd >= 0) {
        char name[32] = {0};
        struct drm_version dv = { .name = name, .name_len = sizeof(name) - 1 };
        if (ioctl(fd, DRM_IOCTL_VERSION, &dv) == 0 && strcmp(name, "rocket") == 0)
            c = (dv.version_major > 1) ? INT_MAX : (int)dv.version_minor;
        close(fd);
    }
    atomic_store(&cached, c);
    return c;
}

/*
 * Does the running kernel actually honor DRM_ROCKET_JOB_BATCHED?
 *
 * This is not a nicety. Chaining is a JOINT layout contract: userspace lays a
 * job's per-task regcmds out contiguously and rewrites each trailer to link to
 * the next, and the kernel must set TASK_NUMBER = task_count so the PC streams
 * them from one kick. A kernel that does not know the flag ignores it and runs
 * that self-chained layout down the stock per-task path (TASK_NUMBER = 1,
 * re-arming each task from the IRQ) -- which corrupts or stalls the job. So
 * "the kernel silently ignored our flag" is NOT a safe degradation, and
 * userspace must never assume support just because ROCKET_BATCH_SUBMIT is set.
 *
 * Probed once, in order of specificity:
 *
 *  1. /sys/module/rocket/parameters/rocket_batch_submit -- created by the kernel
 *     half of the batched-submit patch, so its mere existence proves the flag is
 *     understood. Its VALUE is the master switch: 0 means the kernel forces every
 *     job to the per-task path, which is exactly the mix we must not self-chain
 *     into, so 0 disables chaining here too.
 *
 *  2. Otherwise fall back to the advertised DRM interface version. A kernel that
 *     implements the flag without the kill switch (an upstreamed variant, say)
 *     still reports >= 1.1, the version in which DRM_ROCKET_JOB_BATCHED appears.
 *     Stock mainline leaves .major/.minor unset and reports 0.0.0 -> unsupported.
 *
 * Returns 1 if it is safe to self-chain, 0 otherwise.
 */
int rocket_batched_submit_supported(void)
{
    static _Atomic int cached = -1;
    int c = atomic_load(&cached);
    if (c >= 0)
        return c;

    FILE *f = fopen("/sys/module/rocket/parameters/rocket_batch_submit", "r");
    if (f) {
        int v = 0;
        c = (fscanf(f, "%d", &v) == 1 && v != 0) ? 1 : 0;
        fclose(f);
        if (!c)
            ROCKET_LOGI("rocket_batch_submit=0: the kernel forces every job to the "
                        "per-task path, so chained submit stays off.\n");
        atomic_store(&cached, c);
        return c;
    }

    c = rocket_iface_minor() >= 1;
    atomic_store(&cached, c);
    return c;
}

/*
 * Does the running kernel honor DRM_ROCKET_JOB_PPU_DONE?
 *
 * NOT a nicety either, and for the opposite reason to the batched flag: the submit
 * ioctl REJECTS a flag word it does not recognise. A kernel older than 1.3 does not
 * silently ignore this bit, it fails the submit — so "advisory" is a property of the
 * flag's MEANING (a wrong class costs the grace period, not correctness) and not of
 * sending it to a kernel that predates it. Ask the interface version first.
 *
 * There is no module parameter to key on here, because the flag does not gate a
 * behaviour the kernel can be told to force off — it names which completion bits a
 * job's last program raises. The version is the only signal, and it is enough: 1.3 is
 * the version in which the flag appears.
 *
 * DELIBERATELY VERSION-ONLY — do NOT add an SoC gate here by analogy with
 * rocket_no_dpu_done_supported() below. Bit 2 and version 1.3 mean the same thing on
 * both parts, which is the entire payoff for the RK3588 series skipping 1.2 rather than
 * reusing bit 1, and it is what lets the two parts share one header. An SoC gate here
 * would silently cost the RK3588 the shorter completion the moment a caller sets it.
 * The flag BELOW needs the SoC because its bit is genuinely absent on one part.
 *
 * Returns 1 if it is safe to set, 0 otherwise.
 */
int rocket_ppu_done_supported(void)
{
    static _Atomic int cached = -1;
    int c = atomic_load(&cached);
    if (c >= 0)
        return c;

    c = rocket_iface_minor() >= 3;
    atomic_store(&cached, c);
    return c;
}

/*
 * Does the running kernel honor DRM_ROCKET_JOB_NO_DPU_DONE?
 *
 * THE VERSION NUMBER ALONE CANNOT ANSWER THIS, and that is the whole reason this probe
 * exists separately from the one above. The two SoCs' drivers number their interfaces
 * independently, and the flag sets behind a given minor DIVERGE:
 *
 *      RK3576   1.1 BATCHED   1.2 +NO_DPU_DONE   1.3 +PPU_DONE   1.4 ... 1.6
 *      RK3588   1.1 BATCHED                      1.3 +PPU_DONE
 *
 * The RK3588 series skips both the bit and the version, so its 1.3 carries PPU_DONE and
 * NOT NO_DPU_DONE, while the RK3576's 1.3 carries both. A probe keyed on `minor >= 2`
 * alone would therefore set the bit on an RK3588 1.3 kernel, whose submit ioctl rejects
 * any flag word it does not recognise — so EVERY submit fails with -EINVAL, not just the
 * ones that wanted the hint. Gate it on the SoC first, then on that SoC's version.
 *
 * Advisory in MEANING (a wrong completion class costs the settle period, not
 * correctness) is not the same as safe to SEND; see rocket_ppu_done_supported() above,
 * which makes the same point about the same ioctl.
 *
 * Returns 1 if it is safe to set, 0 otherwise.
 */
int rocket_no_dpu_done_supported(void)
{
    static _Atomic int cached = -1;
    int c = atomic_load(&cached);
    if (c >= 0)
        return c;

    const struct rocket_hw_profile *hw = rocket_hw_current();
    c = (hw && strcmp(hw->name, "rk3576") == 0 && rocket_iface_minor() >= 2) ? 1 : 0;
    atomic_store(&cached, c);
    return c;
}

/*
 * Does the running kernel arm a BATCHED job's completion wait on the task counter?
 *
 * This gates a REFUSAL rather than a flag. The RK3576 driver retires a job when the
 * writing block raises its completion and, failing that, on a deadline — and PC_DONE,
 * where that wait starts, is raised per TASK rather than per kick. On a chained stream
 * the wait therefore starts a few tens of microseconds in and the deadline is covering
 * the whole rest of the stream, not a drain. Past it the job retires with programs
 * still to run: the caller reads a surface that never landed, and the next job is
 * programmed into a core that has not finished the last one.
 *
 * Scaling that deadline by the task count is the obvious response and is not enough: it is a
 * FITTED number, and a stream whose programs each take longer than dpu_grace_us outruns it
 * (one 224x224 k3 convolution at 256 channels row-splits into 75 chained tasks and retires
 * with 8 of them left). From 1.4 the driver reads PC_TASK_STATUS — a live count of the tasks
 * a kick has started and completed — and holds the wait off until the whole kick has retired,
 * which bounds a stream by nothing but the scheduler's job timeout.
 *
 * There is no flag to send and nothing to force off: the version is the only signal,
 * and a wrong answer costs a shorter stream, not correctness.
 *
 * Returns 1 if the running kernel tracks it, 0 otherwise.
 */
int rocket_batch_completion_tracked(void)
{
    static _Atomic int cached = -1;
    int c = atomic_load(&cached);
    if (c >= 0)
        return c;

    c = rocket_iface_minor() >= 4;
    atomic_store(&cached, c);
    return c;
}

/* CHAINING IS AN EXTENSION HERE, NOT THE NATIVE MODE.
 *
 * The stock driver runs a job's tasks one per IRQ; the contiguous self-linked layout
 * needs the batched-submit patch AND its module param. So it stays opt-in
 * (ROCKET_BATCH_SUBMIT=1) even where rocket_batched_submit_supported() says the kernel
 * would honor it — a caller that mixes regcmd lengths in one job must be able to leave
 * it alone, and the gapped per-task layout is the one every gate has always run. */
int rocket_batched_submit_native(void) { return 0; }

/* ONE SUBMIT IS ONE JOB.
 *
 * The mainline driver holds core->in_flight_job across the whole task sequence:
 * rocket_job_handle_irq() programs the next task of the SAME job and only signals
 * the done fence once next_task_idx reaches task_count, so the scheduler cannot put
 * another entity's job on that core in between. CBUF operand reuse therefore holds
 * across a batch here without the caller doing anything, chained or not.
 *
 * Structural, not versioned — there is nothing to probe, and no kernel in this
 * driver's history has decomposed a job. */
int rocket_submit_batch_atomic(void) { return 1; }

/* RANGED CACHE MAINTENANCE (interface 1.5).
 *
 * PREP_BO and FINI_BO sync the WHOLE object — dma_sync_sgtable_for_cpu /
 * _for_device over the BO's entire scatterlist — so a bracket costs what the BO
 * IS rather than what the caller touches. Measured on an RK3576 that is a 1.1 us
 * per-ioctl floor plus about 10.6 GB/s of cache walk each way
 * (tests/rk3576_prep_floor.c), which makes the floor 4-7% of a graph's write
 * guard and the bytes all the rest.
 *
 * The ranged forms name the bytes instead. There is no flag to send: an older
 * kernel does not have the ioctl at all and returns EINVAL/ENOTTY, so the
 * version is the signal and the fallback is the whole-BO form. */
#ifndef DRM_ROCKET_PREP_BO_RANGES
#define DRM_ROCKET_PREP_BO_RANGES  0x04
#define DRM_ROCKET_FINI_BO_RANGES  0x05
struct drm_rocket_bo_range {
    __u64 offset;
    __u64 size;
};
struct drm_rocket_prep_bo_ranges {
    __u32 handle;
    __u32 range_count;
    __u64 ranges;
    __s64 timeout_ns;
    __u64 reserved;
};
struct drm_rocket_fini_bo_ranges {
    __u32 handle;
    __u32 range_count;
    __u64 ranges;
    __u64 reserved;
};
#define DRM_IOCTL_ROCKET_PREP_BO_RANGES \
    DRM_IOW(DRM_COMMAND_BASE + DRM_ROCKET_PREP_BO_RANGES, struct drm_rocket_prep_bo_ranges)
#define DRM_IOCTL_ROCKET_FINI_BO_RANGES \
    DRM_IOW(DRM_COMMAND_BASE + DRM_ROCKET_FINI_BO_RANGES, struct drm_rocket_fini_bo_ranges)
#endif

_Static_assert(sizeof(rocket_bo_range) == sizeof(struct drm_rocket_bo_range),
               "rocket_bo_range must be the uAPI range struct");

int rocket_bo_ranges_supported(void)
{
    static _Atomic int cached = -1;
    int c = atomic_load(&cached);
    if (c >= 0)
        return c;

    c = rocket_iface_minor() >= 5;
    atomic_store(&cached, c);
    return c;
}

static int rkt_bo_prep_wait(int fd, rocket_bo *bo, int dir, uint64_t timeout_ns);

static uint64_t rkt_now_ns(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
}

static int rkt_bo_prep_ranges_wait(int fd, rocket_bo *bo, const rocket_bo_range *r,
                                   unsigned n, uint64_t timeout_ns)
{
    struct drm_rocket_prep_bo_ranges prep = {0};
    int64_t deadline = 0;
    int rc;

    /* The untimed body, not rocket_bo_prep: the public wrapper times this wait already. */
    if (!n || !r || !rocket_bo_ranges_supported())
        return rkt_bo_prep_wait(fd, bo, 0, timeout_ns);

    /* The same absolute-deadline conversion and the same saturation as
     * rocket_bo_prep; see the long note there. */
    if (timeout_ns) {
        struct timespec ts;
        clock_gettime(CLOCK_MONOTONIC, &ts);
        int64_t now = (int64_t)ts.tv_sec * 1000000000LL + ts.tv_nsec;
        deadline = (timeout_ns > (uint64_t)(INT64_MAX - now))
                   ? INT64_MAX : now + (int64_t)timeout_ns;
    }
    prep.handle      = bo->handle;
    prep.range_count = n;
    prep.ranges      = (uint64_t)(uintptr_t)r;
    prep.timeout_ns  = deadline;
    do {
        rc = ioctl(fd, DRM_IOCTL_ROCKET_PREP_BO_RANGES, &prep);
    } while (rc < 0 && errno == EINTR);
    if (rc < 0) {
        int e = errno;
        if (timeout_ns == 0)
            ROCKET_LOGE("rocket_bo_prep_ranges handle=%u n=%u: %s\n",
                        bo->handle, n, strerror(e));
        return -e;
    }
    return 0;
}

/* A timed wait (timeout_ns > 0) is reported to the fence watch, the same as
 * rocket_bo_prep's: see the note there. */
int rocket_bo_prep_ranges(int fd, rocket_bo *bo, const rocket_bo_range *r,
                          unsigned n, uint64_t timeout_ns)
{
    if (!timeout_ns)
        return rkt_bo_prep_ranges_wait(fd, bo, r, n, 0);
    uint64_t t0 = rkt_now_ns();
    int rc = rkt_bo_prep_ranges_wait(fd, bo, r, n, timeout_ns);
    rkt_fence_wait_note(rkt_now_ns() - t0, bo->handle);
    return rc;
}

int rocket_bo_fini_ranges(int fd, rocket_bo *bo, const rocket_bo_range *r,
                          unsigned n)
{
    struct drm_rocket_fini_bo_ranges fini = {0};

    if (!n || !r || !rocket_bo_ranges_supported())
        return rocket_bo_fini(fd, bo);

    fini.handle      = bo->handle;
    fini.range_count = n;
    fini.ranges      = (uint64_t)(uintptr_t)r;
    if (ioctl(fd, DRM_IOCTL_ROCKET_FINI_BO_RANGES, &fini) < 0) {
        int e = errno;
        ROCKET_LOGE("rocket_bo_fini_ranges handle=%u n=%u: %s\n",
                    bo->handle, n, strerror(e));
        return -e;
    }
    return 0;
}

/* ============================================================================
 * SECTION — Device lifecycle (open / close)
 * ==========================================================================*/

/* ---- RK3576: two cores in flight at once compute wrong answers ---------------
 *
 * On this part two NPU jobs EXECUTING simultaneously corrupt each other's results —
 * 96-100% of calls, grossly, over as much as 94% of the surface. The condition is
 * simultaneity, not scheduling: the same two fds driven through a mutex are exact. The
 * resource is the convolution buffer's feature staging path, which the two cores share
 * and which no register program can partition, so there is no encoding that avoids it
 * and no fix on this side of the kernel. [HW sweep, H96 MAX M9]
 *
 * A caller cannot see it coming. With both cores bound, the kernel fans one client's
 * work across them with no userspace change, so the sanctioned way to get the ~1.5x of
 * multiple worker fds is exactly the pattern that corrupts — and a second core buys
 * nothing anyway, since that 1.5x is submit pipelining across fds and is already there
 * with one core bound.
 *
 * So the library refuses to hand out the second fd that would make it possible. The
 * hazard crosses PROCESSES, which this cannot cover; what it does cover is a single
 * process quietly building itself a fan-out on a machine whose DTS enables core 1.
 * The real fix is `status = "disabled"` on the core 1 node.
 *
 * ROCKET_RK3576_ALLOW_MULTI_FD=1 lifts the refusal, for the probes that provoke the
 * corruption on purpose and for anyone who has serialized submits themselves.
 */
static int rocket_bound_core_count(void) { return rocket_sysfs_bound_core_count(); }

/* fds this library currently has open, so the guard fires on the SECOND one. */
static atomic_int rocket_open_fds = 0;

int rocket_open(void)
{
    /* Default device, overridable via ROCKET_DEV for multi-NPU boxes / test rigs. */
    const char *dev = getenv("ROCKET_DEV");
    if (!dev || !*dev) dev = "/dev/accel/accel0";
    int fd = open(dev, O_RDWR | O_CLOEXEC);
    if (fd < 0) {
        ROCKET_LOGE("open(%s): %s\n", dev, strerror(errno));
        return -errno;
    }

    char name[32] = {0};
    struct drm_version dv = { .name = name, .name_len = sizeof(name) - 1 };
    if (ioctl(fd, DRM_IOCTL_VERSION, &dv) < 0) {
        int e = errno;                       /* capture before close()/fprintf clobber */
        ROCKET_LOGE("DRM_IOCTL_VERSION: %s\n", strerror(e));
        close(fd);
        return -e;
    }
    if (strcmp(name, "rocket") != 0) {   /* full NUL-terminated name, not a 6-char prefix */
        ROCKET_LOGE("accel0 driver is '%s', expected 'rocket'\n", name);
        close(fd);
        return -ENODEV;
    }
    if (getenv("ROCKET_DEBUG"))
        ROCKET_LOGD("opened rocket: %s %d.%d.%d\n", name,
                dv.version_major, dv.version_minor, dv.version_patchlevel);
    /* Resolve the hardware profile here, at the one point every user of the device
     * passes through, so a chip we have no profile for warns once per process even
     * on a path (single-task generator, dump tools) that never reads ctx->hw. */
    const struct rocket_hw_profile *hw = rocket_hw_current();

    if (hw && strcmp(hw->name, "rk3576") == 0 && rocket_bound_core_count() > 1) {
        const char *allow = getenv("ROCKET_RK3576_ALLOW_MULTI_FD");
        static atomic_flag warned = ATOMIC_FLAG_INIT;
        if (!atomic_flag_test_and_set(&warned))
            ROCKET_LOGW("rk3576: %d NPU cores are bound. Two jobs running at once on "
                        "this part compute WRONG ANSWERS (a shared CBUF feature path, "
                        "not partitionable from a register program), and the kernel "
                        "spreads work across bound cores by itself. Unbind core 1 "
                        "(echo <dev> > /sys/bus/platform/drivers/rocket/unbind) or set "
                        "status=\"disabled\" on its DT node.\n",
                        rocket_bound_core_count());
        if (atomic_load(&rocket_open_fds) > 0 && !(allow && *allow && *allow != '0')) {
            ROCKET_LOGE("rk3576: refusing a second device fd while %d cores are bound — "
                        "two fds is what puts two jobs in flight at once. Serialize your "
                        "submits and set ROCKET_RK3576_ALLOW_MULTI_FD=1 to override.\n",
                        rocket_bound_core_count());
            close(fd);
            return -EBUSY;
        }
    }

    atomic_fetch_add(&rocket_open_fds, 1);
    return fd;
}

void rocket_close(int fd)
{
    if (fd < 0) return;
    /* BEFORE the close: the pool holds GEM handles on this file, and close() destroys
     * them. Draining after would free handles that no longer exist and, worse, leave the
     * entries for the next fd that lands on this number to hand out. No-op unless
     * ROCKET_RK3576_BO_POOL is on. */
    rocket_rk3576_bo_pool_drain(fd);
    close(fd);
    if (atomic_load(&rocket_open_fds) > 0) atomic_fetch_sub(&rocket_open_fds, 1);
}

/* ============================================================================
 * SECTION — Buffer-object allocation and teardown
 * ==========================================================================*/

int rocket_bo_alloc(int fd, size_t size, rocket_bo *bo)
{
    memset(bo, 0, sizeof(*bo));

    struct drm_rocket_create_bo create = { .size = size };
    if (ioctl(fd, DRM_IOCTL_ROCKET_CREATE_BO, &create) < 0) {
        int e = errno;                       /* capture before fprintf clobber */
        ROCKET_LOGE("ROCKET_CREATE_BO(%zu): %s\n", size, strerror(e));
        return -e;
    }

    void *ptr = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED,
                     fd, create.offset);
    if (ptr == MAP_FAILED) {
        int e = errno;                       /* capture before fprintf/ioctl clobber */
        ROCKET_LOGE("mmap bo: %s\n", strerror(e));
        /* best-effort: close handle via GEM_CLOSE */
        struct drm_gem_close gc = { .handle = create.handle };
        ioctl(fd, DRM_IOCTL_GEM_CLOSE, &gc);
        return -e;
    }

    bo->handle      = create.handle;
    bo->dma_address = create.dma_address;
    bo->mmap_offset = create.offset;
    bo->size        = size;
    bo->ptr         = ptr;
    return 0;
}

int rocket_bo_ensure32(int fd, rocket_bo *bo, size_t need)
{
    if (bo->handle && bo->size >= need)
        return 0;                       /* reuse: contents, including padding, intact */
    rocket_bo_free(fd, bo);             /* grow: release the old one first            */
    int rc = rocket_bo_alloc32(fd, need, bo);
    return rc == 0 ? 1 : rc;            /* 1 = REALLOCATED, so any zero padding is gone */
}

int rocket_bo_alloc32(int fd, size_t size, rocket_bo *bo)
{
    int rc = rocket_bo_alloc(fd, size, bo);
    if (rc != 0)
        return rc;
    /* The LAST byte is what has to be encodable, not the first: a BO based just under
     * 4 GB whose tail crosses it programs an address the hardware reads as wrapped. */
    if (size != 0 && ((bo->dma_address + size - 1) >> 32) != 0) {
        ROCKET_LOGE("rocket_bo_alloc32(%zu): IOVA 0x%llx..0x%llx leaves the low 4 GB the "
                    "regcmd's 32-bit address fields can encode\n", size,
                    (unsigned long long)bo->dma_address,
                    (unsigned long long)(bo->dma_address + size));
        rocket_bo_free(fd, bo);
        return ROCKET_E_DEVICE;   /* an address constraint, not a shortage of memory */
    }
    return 0;
}

void rocket_bo_free(int fd, rocket_bo *bo)
{
    /* munmap/GEM_CLOSE failures are otherwise silent; a failed GEM_CLOSE leaks the GEM
     * handle + its IOVA, and across thousands of resident prepacked weights that could
     * exhaust the per-fd 4 GB IOVA window invisibly. Neither call fails on a healthy
     * teardown, so warn UNCONDITIONALLY (WARN prints by default) — a leak then leaves a
     * forensic trail instead of surfacing as a silent late-run OOM (cf. the loud FINI_BO
     * log). The message is one line per failed free; a systemic failure that floods it is
     * itself the signal. */
    if (bo->ptr) {
        if (munmap(bo->ptr, bo->size) < 0)
            ROCKET_LOGW("rocket_bo_free munmap(handle=%u, size=%zu): %s\n",
                    bo->handle, bo->size, strerror(errno));
        bo->ptr = NULL;
    }
    if (bo->handle) {
        struct drm_gem_close gc = { .handle = bo->handle };
        if (ioctl(fd, DRM_IOCTL_GEM_CLOSE, &gc) < 0)
            ROCKET_LOGW("rocket_bo_free GEM_CLOSE(handle=%u): %s — leaking GEM handle/IOVA\n",
                    bo->handle, strerror(errno));
        bo->handle = 0;
    }
}

/* ============================================================================
 * SECTION — BO cache sync and completion-fence wait
 * ==========================================================================*/

/* ROCKET_BUSY_POLL — spin-poll the completion fence for up to this many
 * microseconds before falling back to the blocking IRQ wait. 0/unset = off.
 *
 * A single-stream LATENCY lever for tiny submit-bound jobs: a blocking wait puts
 * the thread to sleep, so completion costs an IRQ-thread wakeup plus a scheduler
 * round-trip to re-run the waiter. Spinning on a non-blocking completion probe
 * keeps the waiter runnable, so it returns within one probe of the fence
 * signalling. Trade-offs (why it is a knob, not a default): it burns a CPU core
 * while spinning (latency, not throughput — a pooled/oversubscribed run wants
 * that core for other work), and the only completion probe the mainline uAPI
 * exposes (PREP_BO with a zero deadline) re-invalidates the output BO's cache
 * every poll, so it pays only when that output is SMALL. It does NOT skip the
 * kernel IRQ — the mainline `rocket` fence is still IRQ-signalled — so it
 * removes the waiter-side wakeup, not the interrupt itself (that needs a
 * kernel-side poll, a patches/rocket item). The budget itself is host-side and
 * shared across providers — see rocket_busy_poll.h; what is specific to this
 * provider is the probe below. */

/* Non-blocking completion probe: PREP_BO with a zero (=poll) deadline. Returns
 * 0 if the job's writes to this BO have landed (the BO is now CPU-synced),
 * -EBUSY if still in flight, or another negative errno on a real failure. */
static int rkt_prep_poll(int fd, uint32_t handle)
{
    struct drm_rocket_prep_bo prep = { .handle = handle, .timeout_ns = 0 };
    if (ioctl(fd, DRM_IOCTL_ROCKET_PREP_BO, &prep) < 0)
        return -errno;
    return 0;
}

static int rkt_bo_prep_wait(int fd, rocket_bo *bo, int dir, uint64_t timeout_ns)
{
    /* CONFIRMED from rocket_gem.c: drm_rocket_prep_bo is {handle, reserved,
     * timeout_ns}, no direction flag. The kernel waits on the BO's WRITE-usage
     * fence, then always does dma_sync_sgtable_for_cpu(); FINI_BO syncs back for
     * the NPU. `dir` documents caller intent only.
     *
     * CRITICAL: the kernel runs timeout_ns through drm_timeout_abs_to_jiffies()
     * — it is an ABSOLUTE CLOCK_MONOTONIC deadline, not a duration. A small raw
     * value (e.g. "2e9") lands in the past => the wait degrades to a poll and,
     * with the job still running, returns -EBUSY immediately. So we take a
     * RELATIVE timeout here (0 = non-blocking poll) and convert to an absolute
     * deadline. */
    (void)dir;

    /* Optional spin-before-sleep (ROCKET_BUSY_POLL, µs). Only for a real wait
     * (timeout_ns>0); a timeout_ns==0 caller is a plain cache sync, not a wait.
     * Poll the fence for up to the budget, then fall through to the blocking wait
     * below, which arms the FULL timeout_ns afresh (so the worst-case total wait is
     * spin_us + timeout_ns, not the remainder; spin_us is microseconds against a
     * multi-second timeout, so the overshoot is negligible). A successful probe has
     * already CPU-synced the BO, so we return straight away. */
    if (timeout_ns) {
        long spin_us = rkt_busy_poll_us();
        if (spin_us > 0) {
            struct timespec ts;
            clock_gettime(CLOCK_MONOTONIC, &ts);
            int64_t spin_deadline = (int64_t)ts.tv_sec * 1000000000LL + ts.tv_nsec
                                    + (int64_t)spin_us * 1000;
            for (;;) {
                int r = rkt_prep_poll(fd, bo->handle);
                if (r == 0) return 0;            /* completed; BO already synced */
                if (r != -EBUSY) return r;       /* a genuine ioctl failure */
                clock_gettime(CLOCK_MONOTONIC, &ts);
                if ((int64_t)ts.tv_sec * 1000000000LL + ts.tv_nsec >= spin_deadline)
                    break;                       /* budget spent -> blocking wait */
#if defined(__aarch64__)
                __asm__ __volatile__("yield");   /* SEV/WFE hint, no scheduler give-up */
#endif
            }
        }
    }
    int64_t deadline = 0; /* 0 -> kernel poll (drm_timeout_abs_to_jiffies(0)==0) */
    if (timeout_ns) {
        struct timespec ts;
        clock_gettime(CLOCK_MONOTONIC, &ts);
        int64_t now = (int64_t)ts.tv_sec * 1000000000LL + ts.tv_nsec;
        /* Saturate the absolute deadline. timeout_ns is unsigned: a caller passing a
         * huge value (UINT64_MAX is the idiomatic "wait forever") would, through the
         * signed add, wrap `deadline` NEGATIVE — a past deadline, which makes PREP_BO
         * return -EBUSY instantly (a bogus timeout while the job keeps running). Cap at
         * INT64_MAX (~292 years out = "wait forever" in practice); this also absorbs a
         * genuine now+timeout int64 overflow. */
        deadline = (timeout_ns > (uint64_t)(INT64_MAX - now))
                   ? INT64_MAX : now + (int64_t)timeout_ns;
    }
    struct drm_rocket_prep_bo prep = {
        .handle     = bo->handle,
        .timeout_ns = deadline,
    };
    /* The kernel wait (dma_resv_wait_timeout) is INTERRUPTIBLE, so a signal delivered to
     * this thread makes the wait return -ERESTARTSYS, surfacing as ioctl -1/EINTR (unless
     * the handler carries SA_RESTART). A healthy multi-second wait must not become a
     * spurious "WAIT TIMEOUT" because of an unrelated signal — a subprocess reaper's
     * SIGCHLD, a profiler's SIGALRM/SIGPROF, or a Python embedder's non-PEP-475 ioctl. The
     * deadline is ABSOLUTE, so a plain retry resumes waiting to the same deadline with no
     * recompute. (A timeout_ns==0 poll does not sleep, so it is effectively unaffected.) */
    int rc;
    do {
        rc = ioctl(fd, DRM_IOCTL_ROCKET_PREP_BO, &prep);
    } while (rc < 0 && errno == EINTR);
    if (rc < 0) {
        int e = errno;                       /* capture before any clobber */
        /* A timed wait (timeout_ns>0) returning -EBUSY/-ETIMEDOUT is the caller's to
         * report (it owns the retry/abort policy, e.g. the "WAIT TIMEOUT" messages).
         * A timeout_ns==0 sync (prep-for-device before a pack, or a post-wait readback
         * sync) should not fail; many callers ignore its return, so surface it loudly
         * here — otherwise an ioctl failure silently lets the NPU run on, or the host
         * read back, an un-synced buffer (stale-data / silent-corruption). */
        if (timeout_ns == 0)
            ROCKET_LOGE("rocket_bo_prep(sync) PREP_BO handle=%u: %s\n",
                    bo->handle, strerror(e));
        return -e;
    }
    return 0;
}

/* Every timed wait (timeout_ns > 0) is reported to the fence watch with its duration.
 * The kernel retires a job that runs 500 ms and signals its fence, and PREP_BO then
 * returns 0 exactly as it does for a job that completed, so the duration is the only
 * trace a hung job leaves in this process. A timeout_ns == 0 call is a cache sync, not
 * a wait, and is not counted. */
int rocket_bo_prep(int fd, rocket_bo *bo, int dir, uint64_t timeout_ns)
{
    if (!timeout_ns)
        return rkt_bo_prep_wait(fd, bo, dir, 0);
    uint64_t t0 = rkt_now_ns();
    int rc = rkt_bo_prep_wait(fd, bo, dir, timeout_ns);
    rkt_fence_wait_note(rkt_now_ns() - t0, bo->handle);
    return rc;
}

int rocket_bo_fini(int fd, rocket_bo *bo)
{
    struct drm_rocket_fini_bo fini = { .handle = bo->handle };
    if (ioctl(fd, DRM_IOCTL_ROCKET_FINI_BO, &fini) < 0) {
        int e = errno;                       /* capture before any clobber */
        /* FINI_BO syncs the BO back for the NPU and should always succeed; callers
         * universally ignore its return, so a failure here must not be silent (the
         * NPU would then read un-synced host writes). */
        ROCKET_LOGE("rocket_bo_fini FINI_BO handle=%u: %s\n", bo->handle, strerror(e));
        return -e;
    }
    return 0;
}

/* ============================================================================
 * SECTION — Job submission
 * ==========================================================================*/

int rocket_submit_matmul_flags(int fd,
                               const rocket_bo *regcmd_bo, uint32_t regcmd_count,
                               const uint32_t *in_handles,  uint32_t n_in,
                               const uint32_t *out_handles, uint32_t n_out,
                               uint32_t job_flags)
{

    /* drm_rocket_task.regcmd is __u32 — the NPU PC's BASE_ADDRESS register is
     * 32-bit, so the regcmd BO must live in the low 4GB of NPU IOVA space. Fail
     * loudly if it does not, rather than silently truncating a high address (the
     * int8/int4 paths enforce the same window via i8_iova_overflow). */
    if ((regcmd_bo->dma_address >> 32) != 0) {
        ROCKET_LOGE("rocket_submit_matmul: regcmd BO dma_address 0x%llx exceeds "
                "32-bit NPU IOVA window\n", (unsigned long long)regcmd_bo->dma_address);
        return -EINVAL;
    }
    struct drm_rocket_task task = {
        .regcmd       = (uint32_t)regcmd_bo->dma_address,
        .regcmd_count = regcmd_count,
    };

    /* Goes through rkt_submit_one_job so this path declares the same
     * job_struct_size as every other submit site (see rkt_job). */
    return rkt_submit_one_job(fd, &task, 1, in_handles, n_in, out_handles, n_out,
                              job_flags);
}

int rocket_submit_matmul(int fd,
                         const rocket_bo *regcmd_bo, uint32_t regcmd_count,
                         const uint32_t *in_handles,  uint32_t n_in,
                         const uint32_t *out_handles, uint32_t n_out,
                         uint32_t timeout_ms)
{
    (void)timeout_ms;
    return rocket_submit_matmul_flags(fd, regcmd_bo, regcmd_count, in_handles, n_in,
                                      out_handles, n_out, 0u);
}

/* Scratch (bytes) a caller must provide to rocket_submit_tasks_pre for up to
 * max_tasks tasks. Lets the hot path keep the drm_rocket_task[] array resident
 * instead of calloc/free-ing it on every submit. */
size_t rocket_submit_scratch_size(uint32_t max_tasks)
{
    return (size_t)max_tasks * sizeof(struct drm_rocket_task);
}

/* No-alloc core of rocket_submit_tasks: `scratch` is a caller-owned buffer of at
 * least rocket_submit_scratch_size(n_tasks) bytes, reused across submits. Each
 * drm_rocket_task is fully (re)written via a zeroing compound literal, so any
 * reserved uapi fields stay 0 (the compound literal zero-initializes them); elements
 * past n_tasks are never read (task_count = n_tasks). Same semantics/return as the
 * public shim below. */
int rocket_submit_tasks_pre(int fd, void *scratch,
                            const rocket_task_desc *tasks, uint32_t n_tasks,
                            const uint32_t *in_handles,  uint32_t n_in,
                            const uint32_t *out_handles, uint32_t n_out,
                            uint32_t job_flags)
{
    struct drm_rocket_task *dt = (struct drm_rocket_task *)scratch;
    for (uint32_t i = 0; i < n_tasks; i++) {
        dt[i] = (struct drm_rocket_task){
            .regcmd       = tasks[i].regcmd,
            .regcmd_count = tasks[i].regcmd_count,
        };
    }
    return rkt_submit_one_job(fd, dt, n_tasks, in_handles, n_in,
                              out_handles, n_out, job_flags);
}

/* Public shim: allocates the per-submit task array and calls the no-alloc core.
 * Kept for external callers/tests; the matmul hot path uses _pre with resident
 * scratch instead. */
int rocket_submit_tasks(int fd,
                        const rocket_task_desc *tasks, uint32_t n_tasks,
                        const uint32_t *in_handles,  uint32_t n_in,
                        const uint32_t *out_handles, uint32_t n_out)
{
    if (n_tasks == 0) return 0;   // nothing to submit; calloc(0) may return NULL
    struct drm_rocket_task *dt = calloc(n_tasks, sizeof(*dt));
    if (!dt) return -ENOMEM;
    /* Public shim keeps the stock gapped per-task path (batched=0); the chained
     * path is opt-in via rocket_submit_tasks_pre's batched arg on the hot path. */
    int r = rocket_submit_tasks_pre(fd, dt, tasks, n_tasks,
                                    in_handles, n_in, out_handles, n_out, 0);
    free(dt);
    return r;
}

/* Public shim: as rocket_submit_tasks, with a ROCKET_JOB_* bitmask. ROCKET_JOB_BATCHED
 * is only valid when the caller has laid the tasks' regcmds out contiguously and
 * self-chained (rocket_chain.c) AND rocket_batched_submit_supported() is true — a
 * chained layout run down the stock per-task path stalls, so that bit does not degrade
 * gracefully on an older kernel. ROCKET_JOB_NO_DPU_DONE is advisory in MEANING but is NOT
 * always safe to SEND — the ioctl rejects an unrecognised flag word, and the SoCs number
 * their interfaces independently, so gate it with rocket_no_dpu_done_supported(). */
int rocket_submit_tasks_flags(int fd,
                              const rocket_task_desc *tasks, uint32_t n_tasks,
                              const uint32_t *in_handles,  uint32_t n_in,
                              const uint32_t *out_handles, uint32_t n_out,
                              uint32_t job_flags)
{
    if (n_tasks == 0) return 0;   // nothing to submit; calloc(0) may return NULL
    struct drm_rocket_task *dt = calloc(n_tasks, sizeof(*dt));
    if (!dt) return -ENOMEM;
    int r = rocket_submit_tasks_pre(fd, dt, tasks, n_tasks,
                                    in_handles, n_in, out_handles, n_out, job_flags);
    free(dt);
    return r;
}

int rocket_submit_jobs(int fd, const rocket_job_desc *jobs, uint32_t n_jobs)
{
    if (n_jobs == 0) return 0;   // nothing to submit; calloc(0) may return NULL (cf. rocket_submit_tasks)
    /* rkt_job, not drm_rocket_job: the array stride and the declared
     * job_struct_size must both be the ABI-complete size (see rkt_job). */
    rkt_job *dj = calloc(n_jobs, sizeof(*dj));
    struct drm_rocket_task **dts = calloc(n_jobs, sizeof(*dts));
    if (!dj || !dts) { free(dj); free(dts); return -ENOMEM; }

    int r = 0;
    for (uint32_t j = 0; j < n_jobs; j++) {
        /* A task-less job is a caller bug, and it must be caught HERE rather than by the
         * allocation below: calloc(0, ...) is permitted to return NULL, which would read
         * as -ENOMEM and send the caller looking for memory pressure that is not there.
         * (glibc returns non-NULL, so this is portability, not a live failure -- but the
         * sibling rocket_submit_tasks guards exactly this case and says so.) */
        if (jobs[j].n_tasks == 0) {
            ROCKET_LOGE("rocket_submit_jobs: job %u carries no tasks\n", j);
            r = ROCKET_E_SHAPE; goto cleanup;
        }
        dts[j] = calloc(jobs[j].n_tasks, sizeof(struct drm_rocket_task));
        if (!dts[j]) { r = -ENOMEM; goto cleanup; }
        for (uint32_t i = 0; i < jobs[j].n_tasks; i++) {
            dts[j][i].regcmd       = jobs[j].tasks[i].regcmd;
            dts[j][i].regcmd_count = jobs[j].tasks[i].regcmd_count;
        }
        /* Multi-job submit keeps the stock gapped per-task path (batched=0). */
        rkt_job_init(&dj[j], dts[j], jobs[j].n_tasks,
                     jobs[j].in_handles,  jobs[j].n_in,
                     jobs[j].out_handles, jobs[j].n_out, 0);
    }

    struct drm_rocket_submit submit = {
        .jobs            = (uint64_t)(uintptr_t)dj,
        .job_count       = n_jobs,
        .job_struct_size = sizeof(rkt_job),
    };
    uint32_t ntask = 0;
    for (uint32_t j = 0; j < n_jobs; j++) ntask += jobs[j].n_tasks;
    rkt_count_submit(ntask);
    if (ioctl(fd, DRM_IOCTL_ROCKET_SUBMIT, &submit) < 0) {
        ROCKET_LOGE("ROCKET_SUBMIT(%u jobs): %s\n", n_jobs, strerror(errno));
        r = -errno;
    }

cleanup:
    for (uint32_t j = 0; j < n_jobs; j++) free(dts[j]);
    free(dts); free(dj);
    return r;
}
