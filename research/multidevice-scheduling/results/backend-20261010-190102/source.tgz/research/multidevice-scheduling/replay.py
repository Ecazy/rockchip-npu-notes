#!/usr/bin/env python3
"""Replay prior single-device raw submit records through the simulator.

Evidence consumed
-----------------
* ``raw.jsonl`` (or a block directory holding it) with one ``submit`` record per
  blocking ioctl.  Required integer-ns fields: ``host_begin_ns``,
  ``ioctl_begin_ns``, ``ioctl_end_ns``, ``host_done_ns``, ``driver_service_ns``.
* Optional interval evidence: a block-local ``queue-bounds.json`` (written by
  the existing tracing analysis) or ``schedule_analysis.json``.  Each matched
  record then also carries ``driver_entry_ns``, ``enqueue_ns``, ``start_ns`` and
  ``completion_ns`` as ``[lo, hi]`` integer-ns hulls.

What is validated
-----------------
* Host order ``host_begin <= ioctl_begin <= ioctl_end <= host_done``.
* ``0 < service <= ioctl_end - ioctl_begin`` (service fits the blocking ioctl).
* When tracing is present: interval order and hulls, service consistent with
  ``completion``/``start``, ``completion <= ioctl_end``, queue interval equals
  the derived hull, and the observed per-core FIFO (enqueue order matches start
  order).  Any contradiction raises ``ValueError`` and stops the replay.

Accounting
----------
``response        = ioctl_end  - host_begin``
``api_response    = host_done  - host_begin``
``prepare         = ioctl_begin - host_begin``
``ioctl_blocking  = ioctl_end - ioctl_begin``
``ioctl_residual  = ioctl_blocking - service``   (UNKNOWN queue + host work)
``post            = host_done - ioctl_end``

``ioctl_end - service`` is explicitly **not** claimed to be an exact commit
time.  Untraced queueing is unobserved, so ``queue_ns`` stays ``null``; the
residual is reported as an unknown combined bucket, never promoted to a queue.
Traced records report the audited ``queue_ns`` interval only.

The observed release (``ioctl_begin_ns`` untraced, ``enqueue_ns[0]`` traced) and
the observed service are handed to the simulator as a single FIFO device.  The
resulting synthetic schedule is compared against the observed-compatible
schedule: service durations must match exactly and the synthetic interval must
fit inside the observed envelope.  This is an internal-consistency check, not a
prediction of unseen hardware schedules (see ``limits``).
"""

from __future__ import annotations

import argparse
import json
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from simulator import validate_scenario, Simulator  # noqa: E402

SCHEMA_VERSION = 1
TOLERANCE_NS = 1000  # trace text timestamps are microsecond-quantised
INTERVAL_FILES = ("queue-bounds.json", "schedule_analysis.json")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def _int(value):
    return isinstance(value, int) and not isinstance(value, bool)


def _int_field(record, name):
    value = record.get(name)
    require(_int(value) and value >= 0, f"request {record.get('request_id')}: invalid {name}")
    return value


def _interval_field(record, name):
    value = record.get(name)
    require(isinstance(value, list) and len(value) == 2, f"request {record.get('request_id')}: bad {name}")
    lo, hi = value
    require(_int(lo) and _int(hi) and 0 <= lo <= hi, f"request {record.get('request_id')}: disordered {name}")
    return lo, hi


def read_jsonl(path):
    records = []
    for line in pathlib.Path(path).read_text().splitlines():
        line = line.strip()
        if line:
            records.append(json.loads(line))
    return records


def validate_submit(record):
    require(record.get("type") == "submit", "non-submit record")
    rid = record.get("request_id")
    require(_int(rid) and rid >= 0, "invalid request_id")
    host_begin = _int_field(record, "host_begin_ns")
    ioctl_begin = _int_field(record, "ioctl_begin_ns")
    ioctl_end = _int_field(record, "ioctl_end_ns")
    host_done = _int_field(record, "host_done_ns")
    service = _int_field(record, "driver_service_ns")
    require(host_begin <= ioctl_begin <= ioctl_end <= host_done,
            f"request {rid}: host clock order corrupted")
    require(0 < service <= ioctl_end - ioctl_begin,
            f"request {rid}: service does not fit the blocking ioctl")
    require(_int(record.get("task_count", 1)) and record.get("task_count", 1) >= 1,
            f"request {rid}: invalid task_count")
    return record


def _core_of(mask):
    require(_int(mask) and mask in (1, 2, 4), f"invalid actual_mask {mask!r}")
    return mask.bit_length() - 1


def validate_intervals(record):
    rid = record["request_id"]
    service = record["driver_service_ns"]
    ioctl_begin, ioctl_end = record["ioctl_begin_ns"], record["ioctl_end_ns"]
    entry = _interval_field(record, "driver_entry_ns")
    enqueue = _interval_field(record, "enqueue_ns")
    start = _interval_field(record, "start_ns")
    completion = _interval_field(record, "completion_ns")
    require(entry[0] >= ioctl_begin, f"request {rid}: driver entry before ioctl begin")
    require(enqueue[0] >= entry[0], f"request {rid}: enqueue before driver entry")
    require(start[0] >= enqueue[0], f"request {rid}: start before enqueue")
    require(completion[0] >= start[0], f"request {rid}: completion before start")
    require(completion[1] <= ioctl_end + TOLERANCE_NS,
            f"request {rid}: completion after host observation")
    require(completion[0] - start[1] <= service <= completion[1] - start[0],
            f"request {rid}: driver service inconsistent with trace hulls")
    derived_queue = [max(0, start[0] - enqueue[1]), max(0, start[1] - enqueue[0])]
    if "queue_ns" in record and record["queue_ns"] is not None:
        queue = _interval_field(record, "queue_ns")
        require(list(queue) == derived_queue,
                f"request {rid}: queue interval contradicts enqueue/start hulls")
    if "core" in record:
        require(_int(record["core"]) and record["core"] == _core_of(record["actual_mask"]),
                f"request {rid}: core does not match actual_mask")
    if "irq_core" in record:
        require(record["irq_core"] == _core_of(record["actual_mask"]),
                f"request {rid}: irq core does not match actual_mask")
    return derived_queue


def check_core_fifo(rows, intervals_present):
    """Observed per-core FIFO: enqueue order must equal start order when traced.

    Untraced records expose no timing, so FIFO is unobservable there and the
    check is skipped rather than guessed.
    """
    if not intervals_present:
        return {"observable": False, "reason": "untraced: core FIFO timing unobserved"}
    per_core = {}
    for row in rows:
        core = _core_of(row["actual_mask"])
        per_core.setdefault(core, []).append(row)
    for core, members in per_core.items():
        ordered = sorted(members, key=lambda r: r["enqueue_ns"][0])
        starts = [r["start_ns"][0] for r in ordered]
        require(starts == sorted(starts), f"core {core}: start order contradicts enqueue FIFO")
        for previous, nxt in zip(ordered, ordered[1:]):
            require(previous["enqueue_ns"][0] <= nxt["enqueue_ns"][0],
                    f"core {core}: ambiguous enqueue order")
    return {"observable": True, "cores": sorted(per_core)}


def account(record, queue_interval):
    rid = record["request_id"]
    host_begin, ioctl_begin = record["host_begin_ns"], record["ioctl_begin_ns"]
    ioctl_end, host_done = record["ioctl_end_ns"], record["host_done_ns"]
    service = record["driver_service_ns"]
    ioctl_blocking = ioctl_end - ioctl_begin
    residual = ioctl_blocking - service
    require(residual >= 0, f"request {rid}: negative ioctl residual")
    response = ioctl_end - host_begin
    require(service <= response, f"request {rid}: service exceeds response")
    return {
        "request_id": rid,
        "worker": record.get("worker"),
        "core": _core_of(record["actual_mask"]),
        "task_count": record.get("task_count"),
        "host_begin_ns": host_begin,
        "ioctl_begin_ns": ioctl_begin,
        "ioctl_end_ns": ioctl_end,
        "host_done_ns": host_done,
        "prepare_ns": ioctl_begin - host_begin,
        "ioctl_blocking_ns": ioctl_blocking,
        "ioctl_service_ns": service,
        "ioctl_residual_ns": residual,
        "post_ns": host_done - ioctl_end,
        "response_ns": response,
        "api_response_ns": host_done - host_begin,
        "queue_ns": None if queue_interval is None else list(queue_interval),
        "queue_status": "unobserved" if queue_interval is None else "audited_interval_bound",
        # ioctl_end - service is NOT an exact commit timestamp.
        "residual_scope": "ioctl_residual = queue + host work, unresolved",
        "commit_estimate_ns": None,
    }


def _release_ns(record, intervals_present):
    if intervals_present:
        return record["enqueue_ns"][0]
    return record["ioctl_begin_ns"]


def build_synthetic(scenario_rows, device_id, intervals_present):
    """Run the observed release/service through the FIFO simulator.

    Returns ``{job_id: {start_ns, end_ns, service_ns}}``.
    """
    base = min(_release_ns(r, intervals_present) for r in scenario_rows)
    device_name = "replay-device"
    capacity = max(1, sum(r["driver_service_ns"] for r in scenario_rows) + 1)
    jobs = []
    for index, row in enumerate(scenario_rows):
        jobs.append({
            "id": f"submit-{index}",
            "arrival_ns": _release_ns(row, intervals_present) - base,
            "depends_on": [],
            "inputs": [],
            "outputs": [],
            "workspace_bytes": 0,
            "durations_ns": {device_name: row["driver_service_ns"]},
            "eligible_devices": [device_name],
            "task_count": row.get("task_count", 1),
        })
    document = {
        "schema_version": 1,
        "devices": [{"id": device_name, "memory_capacity_bytes": capacity, "measured": True}],
        "links": [],
        "tensors": [],
        "jobs": jobs,
    }
    scenario = validate_scenario(document)
    result = Simulator(scenario, "shortest_queue").run()
    require(result["status"] == "ok", f"synthetic replay failed: {result['failure']}")
    schedule = {}
    for index, job in enumerate(result["jobs"]):
        require(job.get("state", "done") == "done", "synthetic replay left unfinished jobs")
        schedule[f"submit-{index}"] = {
            "start_ns": job["exec_start_ns"] + base,
            "end_ns": job["end_ns"] + base,
            "service_ns": job["compute_ns"],
            "device": device_id,
        }
    return schedule


def replay_records(records, intervals, worker=None):
    submits = [r for r in records if r.get("type") == "submit"]
    require(submits, "no submit records")
    measured = [r for r in submits if not r.get("warmup", False)]
    if worker is not None:
        measured = [r for r in measured if r.get("worker", 0) == worker]
    require(measured, "no measured submit records for the requested worker")
    measured = sorted(measured, key=lambda r: (r.get("worker", 0), r.get("round", 0),
                                               r.get("submit_index", 0)))
    interval_by_id = {}
    if intervals is not None:
        for item in intervals:
            if item.get("type") == "submit":
                interval_by_id[item["request_id"]] = item
    intervals_present = bool(interval_by_id)

    # Validation gates (fail closed).  Merge interval evidence into each
    # measured submit first so the FIFO and accounting steps see one shape.
    observed_rows = []
    for row in measured:
        validate_submit(row)
        merged = dict(row)
        if intervals_present:
            require(row["request_id"] in interval_by_id,
                    f"request {row['request_id']}: missing interval evidence")
            merged.update(interval_by_id[row["request_id"]])
        observed_rows.append(merged)
    fifo = check_core_fifo(observed_rows, intervals_present)

    requests = []
    for order, row in enumerate(observed_rows):
        queue_interval = validate_intervals(row) if intervals_present else None
        entry = account(row, queue_interval)
        entry["order"] = order
        requests.append(entry)

    synthetic = build_synthetic(observed_rows, measured[0].get("actual_mask"), intervals_present)

    compatible = True
    service_match = True
    for order, row in enumerate(observed_rows):
        item = requests[order]
        syn = synthetic[f"submit-{order}"]
        item["synthetic_start_ns"] = syn["start_ns"]
        item["synthetic_end_ns"] = syn["end_ns"]
        if syn["service_ns"] != item["ioctl_service_ns"]:
            service_match = False
        if intervals_present:
            ok = syn["start_ns"] <= row["start_ns"][1]
            ok = ok and syn["end_ns"] <= row["completion_ns"][1] + TOLERANCE_NS
        else:
            ok = syn["end_ns"] <= item["ioctl_end_ns"]
        item["synthetic_compatible"] = bool(ok)
        compatible = compatible and ok

    service_sum = sum(r["ioctl_service_ns"] for r in requests)
    span = max(r["ioctl_end_ns"] for r in requests) - min(r["ioctl_begin_ns"] for r in requests)
    synthetic_makespan = max(r["synthetic_end_ns"] for r in requests) - min(
        r["synthetic_start_ns"] for r in requests)
    queues = [r["queue_ns"] for r in requests if r["queue_ns"] is not None]
    return {
        "schema_version": SCHEMA_VERSION,
        "source": None,
        "worker": worker,
        "kind": "traced" if intervals_present else "untraced",
        "requests": requests,
        "summary": {
            "requests": len(requests),
            "cores": sorted({r["core"] for r in requests}),
            "service_sum_ns": service_sum,
            "service_median_ns": _median([r["ioctl_service_ns"] for r in requests]),
            "observed_span_ns": span,
            "synthetic_makespan_ns": synthetic_makespan,
            "service_durations_match": service_match,
            "synthetic_observed_compatible": compatible,
            "queue_observed": intervals_present,
            "queue_median_ns": None if not queues else _median(
                [(q[0] + q[1]) // 2 for q in queues]),
            "ioctl_residual_median_ns": _median([r["ioctl_residual_ns"] for r in requests]),
            "core_fifo": fifo,
        },
        "limits": limits_text(intervals_present),
    }


def _median(values):
    values = sorted(values)
    if not values:
        return None
    middle = len(values) // 2
    if len(values) % 2:
        return values[middle]
    return (values[middle - 1] + values[middle]) // 2


def limits_text(traced):
    common = [
        "Synthetic schedules are derived from the same observed service durations, so exact agreement validates accounting/FIFO, not predictive power.",
        "task_count and submit packaging are metadata; this replay does not reconstruct register commands or hardware start.",
    ]
    if traced:
        return common + [
            "queue_ns is an audited function-graph interval; ioctl_end-service is NOT an exact commit time.",
            "Some queue interval width is irreducible (microsecond trace quantisation); the residual still contains host work.",
        ]
    return common + [
        "Untraced queueing is unobserved: queue_ns is null and ioctl_residual is a combined queue+host bucket, never a queue estimate.",
        "The release proxy is ioctl_begin_ns; it is not an observed device enqueue time.",
    ]


def load_interval_evidence(block_dir):
    for name in INTERVAL_FILES:
        path = block_dir / name
        if path.exists():
            document = json.loads(path.read_text())
            require(isinstance(document, list), f"{name} must be a list of submit records")
            return document, str(path)
    return None, None


def resolve_block(root, want_trace=None):
    root = pathlib.Path(root)
    if root.is_file():
        return root.parent, None
    if (root / "raw.jsonl").exists():
        return root, None
    if (root / "runs.jsonl").exists():
        ledger = read_jsonl(root / "runs.jsonl")
        for entry in ledger:
            if entry.get("exit_code") != 0:
                continue
            config = entry.get("config", {})
            if config.get("workers") != 1 or config.get("strategy") != "fixed":
                continue
            if config.get("background"):
                continue
            if want_trace is True and not config.get("trace"):
                continue
            if want_trace is False and config.get("trace"):
                continue
            block = root / pathlib.Path(entry["raw"]).parent
            if (block / "raw.jsonl").exists():
                return block, config
        raise ValueError("no matching single-worker fixed block in campaign")
    raise ValueError(f"no raw.jsonl or runs.jsonl under {root}")


def replay(path, worker=None, want_trace=None):
    block, config = resolve_block(path, want_trace)
    records = read_jsonl(block / "raw.jsonl")
    intervals, interval_path = load_interval_evidence(block)
    report = replay_records(records, intervals, worker=worker)
    report["source"] = str(block)
    report["config"] = config
    report["interval_evidence"] = interval_path
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description="Replay single-device raw submit records")
    parser.add_argument("path", type=pathlib.Path,
                        help="raw.jsonl, a block directory, or a campaign directory")
    parser.add_argument("--worker", type=int, default=None)
    parser.add_argument("--trace", dest="want_trace", action="store_true", default=None,
                        help="require traced blocks when resolving a campaign")
    parser.add_argument("--no-trace", dest="want_trace", action="store_false",
                        help="require untraced blocks when resolving a campaign")
    parser.add_argument("--out", type=pathlib.Path, default=None)
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args(argv)
    report = replay(args.path, worker=args.worker, want_trace=args.want_trace)
    text = json.dumps(report, indent=2, sort_keys=True)
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(text + "\n")
    if not args.quiet:
        print(json.dumps({"source": report["source"], "kind": report["kind"],
                          "summary": report["summary"]}, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
